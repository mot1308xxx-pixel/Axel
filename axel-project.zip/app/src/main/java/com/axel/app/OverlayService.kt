package com.axel.app

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Плавающий кружок Axel («A») поверх всех окон. Перетаскивается по краю экрана;
 *  нажатие раскрывает кнопки: 💬 — открыть диалог с Axel, ✖ — выключить голосовой режим. */
class OverlayService : Service() {
    companion object {
        @Volatile var instance: OverlayService? = null
        fun start(c: Context) { try { c.startService(Intent(c, OverlayService::class.java)) } catch (e: Exception) { } }
        fun stop(c: Context) { try { c.stopService(Intent(c, OverlayService::class.java)) } catch (e: Exception) { } }
    }

    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private var bubble: TextView? = null
    private var actions: LinearLayout? = null
    private var expanded = false
    private val h = Handler(Looper.getMainLooper())

    private val BG = 0xF2060607.toInt()
    private val CARD = 0xF214161B.toInt()
    private val ACCENT = 0xFF2F6BFF.toInt()

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val wmP = wm!!

        val dp = resources.displayMetrics.density
        fun px(d: Int) = (d * dp).toInt()

        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 0, 0, 0) }
        actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            visibility = View.GONE
            background = GradientDrawable().apply { setColor(CARD); cornerRadius = px(26).toFloat() }
            setPadding(px(6), px(6), px(6), px(6))
        }
        fun actBtn(label: String, onClick: () -> Unit): TextView = TextView(this).apply {
            text = label; textSize = 18f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(0xFF1B1E24.toInt()); cornerRadius = px(20).toFloat() }
            setPadding(px(12), 0, px(12), 0)
            layoutParams = LinearLayout.LayoutParams(px(46), px(40)).apply { marginEnd = px(4) }
            setOnClickListener { onClick(); collapse() }
        }
        actions?.addView(actBtn("\uD83D\uDCAC") { openChat() })
        actions?.addView(actBtn("\u2715") { shutDown() })

        bubble = TextView(this).apply {
            text = "A"; textSize = 22f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
            background = GradientDrawable().apply { setColor(BG); cornerRadius = px(30).toFloat(); setStroke(px(2), ACCENT) }
            layoutParams = LinearLayout.LayoutParams(px(60), px(60))
        }

        root?.addView(actions)
        root?.addView(bubble)

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START
        params.x = px(12)
        params.y = px(180)

        var downX = 0f; var downY = 0f
        var curX = 0; var curY = 0
        var moved = false
        val view = root!!

        bubble?.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { downX = e.rawX; downY = e.rawY; curX = params.x; curY = params.y; moved = false; true }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                    if (Math.abs(dx) > px(6) || Math.abs(dy) > px(6)) {
                        moved = true
                        params.x = curX + dx; params.y = curY + dy
                        try { wmP.updateViewLayout(view, params) } catch (ex: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) { if (expanded) collapse() else expand() }
                    // прилипание к ближайшему краю
                    val w = resources.displayMetrics.widthPixels
                    val side = (params.x + px(30)) > w / 2
                    params.x = if (side) w - px(74) else px(2)
                    try { wmP.updateViewLayout(view, params) } catch (ex: Exception) { }
                    true
                }
                else -> false
            }
        }

        try { wmP.addView(view, params) } catch (e: Exception) { stopSelf() }
    }

    private fun expand() {
        expanded = true
        actions?.visibility = View.VISIBLE
    }

    private fun collapse() {
        expanded = false
        actions?.visibility = View.GONE
    }

    /** 💬 — мгновенно разворачивает диалог с Axel. */
    private fun openChat() {
        val i = Intent(this, MainActivity::class.java)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        try { startActivity(i) } catch (e: Exception) { }
    }

    /** ✖ — полностью отключает голосовой режим и убирает кружок. */
    private fun shutDown() {
        getSharedPreferences("axel", 0).edit().putBoolean("enabled", false).putBoolean("callmode", false).apply()
        VoiceService.stop(this)
        MainActivity.inst?.syncUi()
        stopSelf()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY

    override fun onDestroy() {
        instance = null
        try { root?.let { wm?.removeView(it) } } catch (e: Exception) { }
        root = null; bubble = null; actions = null
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
