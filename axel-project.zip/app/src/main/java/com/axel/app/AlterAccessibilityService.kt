package com.axel.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/** Руки и глаза Axel: реальные нажатия, листание, ввод текста, скриншоты экрана. Вызывается из фонового потока. */
class AlterAccessibilityService : AccessibilityService() {
    class Shot(val b64: String, val w: Int, val h: Int)

    companion object {
        @Volatile var instance: AlterAccessibilityService? = null
    }

    private val exec = Executors.newSingleThreadExecutor()
    @Volatile private var lastShot: Shot? = null
    @Volatile private var lastShotAt = 0L
    private val ws = Regex("\\s+")

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        MainActivity.inst?.syncUi()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        MainActivity.inst?.syncUi()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---------- дерево экрана ----------
    private fun roots(): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        try {
            for (w in windows) {
                val r = w.root
                if (r != null) out.add(r)
            }
        } catch (e: Exception) { }
        if (out.isEmpty()) {
            val r = rootInActiveWindow
            if (r != null) out.add(r)
        }
        return out.filter { it.packageName?.toString() != packageName }
    }

    private fun norm(s: CharSequence?): String =
        ws.replace((s?.toString() ?: "").lowercase().replace('ё', 'е'), " ").trim()

    private fun forEachNode(visit: (AccessibilityNodeInfo) -> Boolean) {
        for (root in roots()) {
            val stack = ArrayDeque<AccessibilityNodeInfo>()
            stack.add(root)
            var count = 0
            while (stack.isNotEmpty() && count < 5000) {
                val n = stack.removeLast()
                count++
                if (visit(n)) return
                for (i in 0 until n.childCount) {
                    val ch = n.getChild(i)
                    if (ch != null) stack.add(ch)
                }
            }
        }
    }

    /** Лучшее совпадение по тексту или описанию: точное лучше «начинается», лучше «содержит». */
    fun findBest(queries: List<String>): AccessibilityNodeInfo? {
        val qs = queries.map { norm(it) }.filter { it.isNotEmpty() }
        if (qs.isEmpty()) return null
        var best: AccessibilityNodeInfo? = null
        var bestScore = Int.MAX_VALUE
        forEachNode { n ->
            if (n.isVisibleToUser) {
                var sc = Int.MAX_VALUE
                for (t in arrayOf(norm(n.text), norm(n.contentDescription))) {
                    if (t.isEmpty()) continue
                    for (q in qs) {
                        val s = when {
                            t == q -> 0
                            t.startsWith(q) -> 1
                            q.length >= 2 && t.contains(q) -> 2
                            else -> Int.MAX_VALUE
                        }
                        if (s < sc) sc = s
                    }
                }
                if (sc != Int.MAX_VALUE) {
                    val len = n.text?.length ?: n.contentDescription?.length ?: 0
                    val total = sc * 1000 + len
                    if (total < bestScore) {
                        bestScore = total
                        best = n
                    }
                }
            }
            false
        }
        return best
    }

    fun findByText(q: String): AccessibilityNodeInfo? = findBest(listOf(q))

    fun findEditable(): AccessibilityNodeInfo? {
        for (r in roots()) {
            val f = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (f != null && f.isEditable) return f
        }
        var found: AccessibilityNodeInfo? = null
        forEachNode { n ->
            if (n.isEditable && n.isVisibleToUser) {
                found = n
                true
            } else false
        }
        return found
    }

    // ---------- жесты ----------
    fun invalidateShot() { lastShot = null }

    private fun dispatch(s: GestureDescription.StrokeDescription): Boolean {
        val g = GestureDescription.Builder().addStroke(s).build()
        val ok = AtomicBoolean(false)
        val latch = CountDownLatch(1)
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                ok.set(true)
                latch.countDown()
            }
            override fun onCancelled(gestureDescription: GestureDescription?) {
                latch.countDown()
            }
        }
        if (!dispatchGesture(g, cb, null)) return false
        latch.await(4, TimeUnit.SECONDS)
        return ok.get()
    }

    fun tapAt(x: Float, y: Float): Boolean {
        invalidateShot()
        val dm = resources.displayMetrics
        val p = Path()
        p.moveTo(x.coerceIn(1f, dm.widthPixels - 1f), y.coerceIn(1f, dm.heightPixels - 1f))
        return dispatch(GestureDescription.StrokeDescription(p, 0, 60))
    }

    fun drag(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long = 350): Boolean {
        invalidateShot()
        val p = Path()
        p.moveTo(x1, y1)
        p.lineTo(x2, y2)
        return dispatch(GestureDescription.StrokeDescription(p, 0, ms))
    }

    /** up/down — куда листаем страницу («вниз» — к следующему содержимому); left/right — куда ведём палец. */
    fun swipe(dir: String, frac: Float): Boolean {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val f = frac.coerceIn(0.2f, 0.8f)
        val cx = w / 2
        val cy = h / 2
        val dx = w * f / 2
        val dy = h * f / 2
        return when (dir) {
            "up" -> drag(cx, cy - dy, cx, cy + dy)
            "left" -> drag(cx + dx, cy, cx - dx, cy)
            "right" -> drag(cx - dx, cy, cx + dx, cy)
            else -> drag(cx, cy + dy, cx, cy - dy)
        }
    }

    fun clickNode(n: AccessibilityNodeInfo): Boolean {
        invalidateShot()
        var p: AccessibilityNodeInfo? = n
        var depth = 0
        while (p != null && depth < 6) {
            if (p.isClickable && p.isEnabled) {
                if (p.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
                break
            }
            p = p.parent
            depth++
        }
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.width() > 0 && r.height() > 0) return tapAt(r.exactCenterX(), r.exactCenterY())
        return false
    }

    // ---------- ввод текста ----------
    fun setText(n: AccessibilityNodeInfo, text: String): Boolean {
        invalidateShot()
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun typeText(text: String): Boolean {
        val n = findEditable() ?: return false
        return setText(n, text)
    }

    fun imeEnter(n: AccessibilityNodeInfo): Boolean {
        if (Build.VERSION.SDK_INT < 30) return false
        return n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
    }

    // ---------- переключатели в шторке быстрых настроек ----------
    private fun parseState(s: String): Boolean? {
        if (s.isEmpty()) return null
        if (s.contains("выкл") || s.contains("отключ") || Regex("\\boff\\b").containsMatchIn(s)) return false
        if (s.contains("вкл") || Regex("\\bon\\b").containsMatchIn(s)) return true
        return null
    }

    private fun tileState(n: AccessibilityNodeInfo): Boolean? {
        var p: AccessibilityNodeInfo? = n
        var depth = 0
        while (p != null && depth < 5) {
            if (p.isCheckable) return p.isChecked
            if (Build.VERSION.SDK_INT >= 30) {
                val st = parseState(norm(p.stateDescription))
                if (st != null) return st
            }
            val d = parseState(norm(p.contentDescription))
            if (d != null) return d
            p = p.parent
            depth++
        }
        return null
    }

    /** 0 — не нашёл; 1 — переключил; 2 — уже в нужном состоянии. */
    fun toggleTile(labels: List<String>, on: Boolean?): Int {
        val dm = resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        performGlobalAction(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS)
        Thread.sleep(900)
        var tile = findBest(labels)
        if (tile == null) {
            drag(w / 2, h * 0.25f, w / 2, h * 0.75f)
            Thread.sleep(700)
            tile = findBest(labels)
        }
        var page = 0
        while (tile == null && page < 3) {
            drag(w * 0.8f, h * 0.3f, w * 0.2f, h * 0.3f)
            Thread.sleep(600)
            tile = findBest(labels)
            page++
        }
        if (tile == null) {
            performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            return 0
        }
        val state = tileState(tile)
        if (on != null && state != null && state == on) {
            performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
            return 2
        }
        clickNode(tile)
        Thread.sleep(500)
        performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
        return 1
    }

    // ---------- скрытый скриншот ----------
    /** Снимок только в памяти: сжимается в JPEG (80%), кэш — 3 секунды, на диск не пишется. */
    fun screenshot(): Shot? {
        if (Build.VERSION.SDK_INT < 30) return null
        val cached = lastShot
        if (cached != null && System.currentTimeMillis() - lastShotAt < 3000) return cached
        val latch = CountDownLatch(1)
        val holder = arrayOfNulls<Bitmap>(1)
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, exec, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(screenshot: AccessibilityService.ScreenshotResult) {
                    try {
                        val hb = screenshot.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(hb, screenshot.colorSpace)
                        holder[0] = bmp?.copy(Bitmap.Config.ARGB_8888, false)
                        hb.close()
                    } catch (e: Exception) { }
                    latch.countDown()
                }

                override fun onFailure(errorCode: Int) {
                    latch.countDown()
                }
            })
        } catch (e: Exception) {
            return null
        }
        latch.await(5, TimeUnit.SECONDS)
        val bmp = holder[0] ?: return null
        val w = bmp.width
        val h = bmp.height
        val sc = minOf(1f, 1024f / maxOf(w, h))
        val sb = if (sc < 1f) Bitmap.createScaledBitmap(bmp, (w * sc).toInt(), (h * sc).toInt(), true) else bmp
        val bos = ByteArrayOutputStream()
        sb.compress(Bitmap.CompressFormat.JPEG, 80, bos)
        val shot = Shot(Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP), w, h)
        lastShot = shot
        lastShotAt = System.currentTimeMillis()
        return shot
    }
}
