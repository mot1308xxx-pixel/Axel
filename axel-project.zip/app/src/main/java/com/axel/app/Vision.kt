package com.axel.app

import android.graphics.Bitmap
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

/** Скрытое зрение Axel: скриншот живёт только в оперативной памяти, сжимается до JPEG 80%
 *  и уходит в Vision-модель с реальным разрешением экрана в пикселях. В чат никогда не отправляется. */
object Vision {
    sealed class Res {
        data class Found(val x: Int, val y: Int) : Res()
        data class Scroll(val dir: String) : Res()
        object Miss : Res()
    }

    private fun models(base: String, all: List<String>): List<String> {
        val pick = when {
            base.contains("generativelanguage") -> all.filter { it.contains("flash") && !it.contains("lite") } + all.filter { it.contains("flash") }
            base.contains("openrouter") -> listOf("nvidia/nemotron-3.5-super-vl:free", "google/gemma-4-31b-it:free")
            base.contains("groq") -> listOf("meta-llama/llama-4-scout-17b-16e-instruct", "meta-llama/llama-4-maverick-17b-128e-instruct")
            base.contains("openai") -> listOf("gpt-4o-mini", "gpt-4.1-mini", "gpt-4o")
            base.contains("mistral") -> listOf("mistral-small-latest", "pixtral-12b-latest")
            else -> emptyList()
        }
        val vis = all.filter { Regex("flash|gemini|vl|vision|llama-4|pixtral|gpt-4o|gpt-4\\.1|nemo").containsMatchIn(it.lowercase()) }
        return (pick + vis + all.take(2)).distinct()
    }

    private fun num(s: String, k: String): Double? =
        Regex("\"$k\"\\s*:\\s*(-?[0-9.]+)").find(s)?.groupValues?.get(1)?.toDoubleOrNull()

    /**
     * Ищет элемент на скрытом скриншоте. bmp — кадр в реальном разрешении экрана.
     * Возвращает координаты центра в физических пикселях устройства или команду свайпа.
     * Вызывать не в основном потоке.
     */
    fun locate(base: String, key: String, all: List<String>, bmp: Bitmap, desc: String, statusBarPx: Int = 0): Res {
        val W = bmp.width
        val H = bmp.height
        val k = 1280.0 / maxOf(W, H)
        val small = if (k < 1) Bitmap.createScaledBitmap(bmp, (W * k).toInt(), (H * k).toInt(), true) else bmp
        val bo = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 80, bo)
        val b64 = Base64.encodeToString(bo.toByteArray(), Base64.NO_WRAP)
        val sb = if (statusBarPx > 0) " Самая верхняя полоса экрана (статус-бар) занимает примерно $statusBarPx пикселей по высоте и не содержит кнопок." else ""
        val prompt =
            "Это скриншот экрана телефона в разрешении ${W}x${H} пикселей (ширина x высота).$sb " +
            "Найди на скриншоте нужную кнопку или элемент (например, \"Бойцы\" или \"Леон\"): «$desc». " +
            "Вычисли точные координаты центра этого элемента в пикселях с учётом разрешения экрана. " +
            "Если на скриншоте плитка быстрых настроек Android (Wi-Fi, Bluetooth и подобные) с круглой иконкой слева и текстом справа — " +
            "возвращай координаты центра именно круглой иконки переключателя слева, а не текста. " +
            "Если элемент есть — верни строго JSON без пояснений: {\"status\":\"found\",\"action\":\"click\",\"x\":число,\"y\":число,\"reply\":\"Хорошо, нажимаю\"}. " +
            "Если элемента сейчас нет на экране — верни строго JSON: {\"status\":\"scroll\",\"direction\":\"down\",\"reply\":\"Листаю\"}, " +
            "где direction — down, up, left или right (в какую сторону листать, чтобы элемент появился). Никакого текста кроме JSON."
        for (m in models(base, all).take(3)) {
            try {
                val img = JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64," + b64))
                val txt = JSONObject().put("type", "text").put("text", prompt)
                val msg = JSONObject().put("role", "user").put("content", JSONArray().put(txt).put(img))
                val body = JSONObject().put("model", m).put("temperature", 0).put("max_tokens", 300).put("messages", JSONArray().put(msg))
                val con = URL("$base/chat/completions").openConnection() as HttpURLConnection
                con.requestMethod = "POST"
                con.connectTimeout = 8000
                con.readTimeout = 25000
                con.doOutput = true
                con.setRequestProperty("Content-Type", "application/json")
                con.setRequestProperty("Authorization", "Bearer $key")
                con.outputStream.use { it.write(body.toString().toByteArray()) }
                if (con.responseCode !in 200..299) continue
                val resp = con.inputStream.bufferedReader().readText()
                val message = JSONObject(resp).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message") ?: continue
                val ans = if (!message.isNull("content")) message.optString("content")
                          else if (!message.isNull("reasoning")) message.optString("reasoning")
                          else if (!message.isNull("reasoning_content")) message.optString("reasoning_content") else ""
                // лишний текст от модели не ломает парсер: извлекаем только { ... }
                val j = Regex("\\{[\\s\\S]*\\}").find(ans)?.value ?: ans
                val st = Regex("\"status\"\\s*:\\s*\"([a-z]+)\"").find(j)?.groupValues?.get(1)?.lowercase()
                if (st == "scroll") {
                    val dir = Regex("\"direction\"\\s*:\\s*\"(down|up|left|right)\"").find(ans)?.groupValues?.get(1)?.lowercase() ?: "down"
                    return Res.Scroll(dir)
                }
                // строгий JSON: координаты уже в физических пикселях
                val x = num(j, "x")
                val y = num(j, "y")
                if (x != null && y != null) {
                    val cx = x.coerceIn(2.0, (W - 3).toDouble()).toInt()
                    val cy = y.coerceIn(2.0, (H - 3).toDouble()).toInt()
                    if (x <= W && y <= H) return Res.Found(cx, cy)
                }
                // запасной формат: box_2d от 0 до 1000
                val bx = Regex("\"box_2d\"\\s*:\\s*\\[\\s*([0-9.]+)\\s*,\\s*([0-9.]+)\\s*,\\s*([0-9.]+)\\s*,\\s*([0-9.]+)").find(j)
                if (bx != null) {
                    val g = bx.groupValues.drop(1).map { it.toDouble() }
                    val cx = ((g[1] + g[3]) / 2000.0 * W).toInt().coerceIn(2, W - 3)
                    val cy = ((g[0] + g[2]) / 2000.0 * H).toInt().coerceIn(2, H - 3)
                    return Res.Found(cx, cy)
                }
                // запасной формат: относительные 0..1
                val rx = num(j, "rx")
                val ry = num(j, "ry")
                if (rx != null && ry != null && rx <= 1.0 && ry <= 1.0) {
                    return Res.Found((rx * W).toInt().coerceIn(2, W - 3), (ry * H).toInt().coerceIn(2, H - 3))
                }
            } catch (e: Exception) { }
        }
        return Res.Miss
    }
}
