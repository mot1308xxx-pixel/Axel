package com.axel.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Message
import android.os.PowerManager
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    companion object {
        @Volatile var visible = false
        @Volatile var inst: MainActivity? = null
        fun hide() { inst?.runOnUiThread { inst?.moveTaskToBack(true) } }
    }

    private lateinit var web: WebView
    private var pendingCmd: String? = null
    private fun pr() = getSharedPreferences("axel", 0)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        inst = this
        window.statusBarColor = 0xFF060607.toInt()
        window.navigationBarColor = 0xFF060607.toInt()
        pendingCmd = intent?.getStringExtra("cmd")
        web = WebView(this)
        web.setBackgroundColor(0xFF060607.toInt())
        setContentView(web)
        val loader = WebViewAssetLoader.Builder().addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this)).build()
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.settings.javaScriptCanOpenWindowsAutomatically = true
        web.settings.setSupportMultipleWindows(true)
        web.addJavascriptInterface(Bridge(), "AlterAndroid")
        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? = loader.shouldInterceptRequest(r.url)
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                if (r.url.host == "appassets.androidplatform.net") return false
                openExternal(r.url.toString()); return true
            }
            override fun onPageFinished(v: WebView, u: String?) { deliver() }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsConfirm(v: WebView, u: String?, m: String?, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m)
                    .setPositiveButton("ОК") { _, _ -> r.confirm() }
                    .setNegativeButton("Отмена") { _, _ -> r.cancel() }
                    .setOnCancelListener { r.cancel() }.show()
                return true
            }
            override fun onJsAlert(v: WebView, u: String?, m: String?, r: JsResult): Boolean {
                AlertDialog.Builder(this@MainActivity).setMessage(m).setPositiveButton("ОК") { _, _ -> r.confirm() }
                    .setOnCancelListener { r.confirm() }.show()
                return true
            }
            override fun onCreateWindow(v: WebView, d: Boolean, u: Boolean, msg: Message): Boolean {
                val t = WebView(this@MainActivity)
                t.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean { openExternal(r.url.toString()); return true }
                }
                (msg.obj as WebView.WebViewTransport).webView = t
                msg.sendToTarget()
                return true
            }
        }
        Speaker.init(this)
        web.loadUrl("https://appassets.androidplatform.net/assets/index.html")
        startVoiceIfNeeded()
    }

    fun startVoiceIfNeeded() {
        if (pr().getBoolean("enabled", true) && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED && VoiceService.instance == null) VoiceService.start(this)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        startVoiceIfNeeded(); syncUi()
    }

    override fun onNewIntent(i: Intent) {
        super.onNewIntent(i)
        pendingCmd = i.getStringExtra("cmd")
        deliver()
    }

    private fun deliver() {
        val c = pendingCmd ?: return
        pendingCmd = null
        web.postDelayed({ web.evaluateJavascript("window.alterIncoming&&alterIncoming(" + JSONObject.quote(c) + ")", null) }, 500)
    }

    override fun onResume() { super.onResume(); visible = true; startVoiceIfNeeded(); ping(); syncUi() }
    override fun onPause() { visible = false; super.onPause() }
    override fun onDestroy() { if (inst === this) inst = null; super.onDestroy() }

    private fun openExternal(url: String) {
        try {
            if (url.startsWith("intent:")) {
                val i = Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                try { startActivity(i) } catch (e: Exception) {
                    val fb = i.getStringExtra("browser_fallback_url")
                    if (fb != null) startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(fb)))
                }
            } else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {}
    }

    private fun js(code: String) { web.post { web.evaluateJavascript(code, null) } }

    /** Реальное списание лимита: накопленное Kotlin'ом (pendingCost) транслируется в window.onApiRequestCompleted. */
    fun ping() {
        val pc = pr().getInt("pendingCost", 0)
        if (pc > 0) {
            pr().edit().putInt("pendingCost", 0).apply()
            js("window.onApiRequestCompleted&&onApiRequestCompleted($pc)")
        }
        js("window.alterSync&&alterSync()")
    }
    fun syncUi() { js("window.syncTop&&syncTop()") }

    inner class Bridge {
        @JavascriptInterface fun openApp(name: String, pkg: String): Boolean = Phone.openApp(this@MainActivity, name, pkg)

        @JavascriptInterface fun permissionStatus(): String {
            val a = this@MainActivity
            val o = JSONObject()
            o.put("mic", a.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
            o.put("accessibility", Settings.Secure.getString(a.contentResolver, "enabled_accessibility_services")?.contains(a.packageName) == true)
            o.put("notifications", Build.VERSION.SDK_INT < 33 || a.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
            o.put("background", (a.getSystemService(Context.POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(a.packageName))
            o.put("overlay", Settings.canDrawOverlays(a))
            o.put("write", Settings.System.canWrite(a))
            return o.toString()
        }

        @JavascriptInterface fun requestPermission(id: String) {
            runOnUiThread {
                when (id) {
                    "mic" -> requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
                    "notifications" -> if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 2)
                    "accessibility" -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    "background" -> startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
                    "overlay" -> startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    "write" -> startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName")))
                }
            }
        }

        // ---------- голосовой режим «звонка» с плавающим кружком ----------

        /** ok | need_mic | need_overlay — веб-слой показывает подсказку. */
        @JavascriptInterface fun startCallMode(): String {
            val a = this@MainActivity
            if (a.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return "need_mic"
            if (!Settings.canDrawOverlays(a)) return "need_overlay"
            pr().edit().putBoolean("enabled", true).putBoolean("callmode", true).apply()
            VoiceService.start(a)
            OverlayService.start(a)
            return "ok"
        }

        @JavascriptInterface fun stopCallMode() {
            pr().edit().putBoolean("enabled", false).putBoolean("callmode", false).apply()
            runOnUiThread {
                VoiceService.stop(this@MainActivity)
                OverlayService.stop(this@MainActivity)
                syncUi()
            }
        }

        @JavascriptInterface fun callMode(): Boolean = pr().getBoolean("callmode", false) && VoiceService.instance != null

        @JavascriptInterface fun listening(): Boolean = VoiceService.instance != null
        @JavascriptInterface fun setListening(on: Boolean): Boolean {
            if (on && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
            pr().edit().putBoolean("enabled", on).apply()
            runOnUiThread { if (on) VoiceService.start(this@MainActivity) else if (!pr().getBoolean("callmode", false)) VoiceService.stop(this@MainActivity) }
            return true
        }

        @JavascriptInterface fun getWakePhrase(): String = pr().getString("phrase", "Аксель") ?: "Аксель"
        @JavascriptInterface fun setWakePhrase(p: String) { pr().edit().putString("phrase", p.trim().take(30)).apply() }
        @JavascriptInterface fun bgSpeak(): Boolean = !Speaker.muted(this@MainActivity)
        @JavascriptInterface fun setBgSpeak(on: Boolean) { Speaker.setMuted(this@MainActivity, !on) }
        @JavascriptInterface fun setLang(tag: String) { Speaker.setLang(this@MainActivity, tag) }
        @JavascriptInterface fun setVoiceEngine(e: String) { Speaker.setEngine(this@MainActivity, e) }
        @JavascriptInterface fun speak(text: String, rate: Float) {
            Speaker.say(this@MainActivity, text) { js("window.__ttsDone&&__ttsDone()") }
        }
        @JavascriptInterface fun setAI(key: String, base: String, models: String) { pr().edit().putString("key", key).putString("base", base).putString("models", models).apply() }
        @JavascriptInterface fun stopSpeak() { Speaker.stop() }

        /** Команда из чата: выполняется в фоне, ответ приходит в window.__alterReply. */
        @JavascriptInterface fun ask(id: String, text: String, hist: String) {
            Thread {
                val h = ArrayList<Pair<String, String>>()
                try { val a = JSONArray(hist); for (i in 0 until a.length()) { val o = a.getJSONObject(i); h.add(Pair(o.getString("role"), o.getString("content"))) } } catch (e: Exception) { }
                val rep = try { Brain.handle(this@MainActivity, text, h) } catch (e: Exception) { Brain.Reply("Ошибка: " + (e.message ?: ""), emptyList()) }
                // сначала мгновенно отдаём ответ в чат, озвучка идёт параллельно
                js("window.__alterReply&&__alterReply(" + JSONObject.quote(id) + "," + JSONObject.quote(Brain.json(rep).toString()) + ")")
                Speaker.say(this@MainActivity, rep.say)
            }.start()
        }

        @JavascriptInterface fun drainLog(): String {
            val s = pr().getString("log", "[]") ?: "[]"
            pr().edit().putString("log", "[]").apply()
            return s
        }
    }
}
