package com.axel.app

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Фоновое прослушивание слова «Аксель»: службе переднего плана с уведомлением «Axel вас слушает». */
class VoiceService : Service() {
    companion object {
        @Volatile var instance: VoiceService? = null
        private const val CH = "axel_listen"
        private const val NID = 71
        private const val ACT_MUTE = "com.axel.app.MUTE"
        private const val ACT_OFF = "com.axel.app.OFF"

        fun start(c: Context) {
            try { c.startForegroundService(Intent(c, VoiceService::class.java)) } catch (e: Exception) { }
        }

        fun stop(c: Context) {
            try { c.stopService(Intent(c, VoiceService::class.java)) } catch (e: Exception) { }
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var running = false
    private var awaitUntil = 0L
    private val restart = Runnable { begin() }

    private fun pr() = getSharedPreferences("axel", 0)

    override fun onCreate() {
        super.onCreate()
        instance = this
        running = true
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH, "Axel слушает", NotificationManager.IMPORTANCE_LOW))
        try {
            val n = buildNotif()
            if (Build.VERSION.SDK_INT >= 30) startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            else startForeground(NID, n)
        } catch (e: Exception) {
            running = false
            stopSelf()
            return
        }
        Speaker.init(this)
        MainActivity.inst?.syncUi()
        main.post { begin() }
    }

    private fun buildNotif(): Notification {
        val fl = PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP), fl
        )
        val mute = PendingIntent.getService(this, 1, Intent(this, VoiceService::class.java).setAction(ACT_MUTE), fl)
        val off = PendingIntent.getService(this, 2, Intent(this, VoiceService::class.java).setAction(ACT_OFF), fl)
        val muted = Speaker.muted(this)
        val icon = Icon.createWithResource(this, R.drawable.ic_notif)
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_notif)
            .setContentTitle("Axel вас слушает")
            .setContentText("Скажите: «Аксель…»")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(Notification.Action.Builder(icon, if (muted) "Со звуком" else "Без звука", mute).build())
            .addAction(Notification.Action.Builder(icon, "Выключить", off).build())
            .build()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            ACT_MUTE -> {
                Speaker.setMuted(this, !Speaker.muted(this))
                (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NID, buildNotif())
            }
            ACT_OFF -> {
                shutDown()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun shutDown() {
        pr().edit().putBoolean("enabled", false).putBoolean("callmode", false).apply()
        OverlayService.stop(this)
        stopSelf()
    }

    // ---------- распознавание речи ----------
    private fun retry(ms: Long) {
        if (!running) return
        main.removeCallbacks(restart)
        main.postDelayed(restart, ms)
    }

    private fun begin() {
        if (!running) return
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            running = false
            stopSelf()
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            retry(10000)
            return
        }
        try {
            sr?.destroy()
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            r.setRecognitionListener(listener)
            sr = r
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Speaker.langTag(this))
            i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            r.startListening(i)
        } catch (e: Exception) {
            retry(2000)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    running = false
                    stopSelf()
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> retry(1500)
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> retry(200)
                else -> retry(1200)
            }
        }

        override fun onResults(results: Bundle?) {
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (!list.isNullOrEmpty()) heard(list)
            retry(200)
        }
    }

    private fun heard(alts: List<String>) {
        if (Speaker.speaking) return
        val now = SystemClock.elapsedRealtime()
        val phrase = (pr().getString("phrase", "Аксель") ?: "Аксель").lowercase().replace('ё', 'е').trim()
        val extra = if (phrase.isNotEmpty()) "|" + Regex.escape(phrase) else ""
        val wake = Regex("(?<![\\p{L}\\p{N}])(аксель|алекс|axel|эксель|оксель|аксел$extra)(?![\\p{L}\\p{N}])")
        var found: String? = null
        for (t in alts) {
            val low = t.lowercase().replace('ё', 'е')
            val m = wake.find(low)
            if (m != null) {
                val src = if (low.length == t.length) t else low
                found = src.substring(m.range.last + 1).trim(' ', ',', '.', '!', '?', '-')
                break
            }
        }
        val cmd: String = found ?: (if (now < awaitUntil) alts[0].trim() else return)
        if (cmd.isEmpty()) {
            awaitUntil = now + 8000
            Speaker.say(this, "Слушаю")
            return
        }
        awaitUntil = 0
        execute(cmd)
    }

    private fun execute(cmd: String) {
        Thread {
            val rep = try {
                Brain.handle(this, cmd, null)
            } catch (e: Exception) {
                Brain.Reply("Ошибка: " + (e.message ?: ""), emptyList())
            }
            Brain.log(this, cmd, rep)
            Speaker.say(this, rep.say)
        }.start()
    }

    override fun onDestroy() {
        running = false
        instance = null
        main.removeCallbacksAndMessages(null)
        try { sr?.destroy() } catch (e: Exception) { }
        sr = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (e: Exception) { }
        MainActivity.inst?.syncUi()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
