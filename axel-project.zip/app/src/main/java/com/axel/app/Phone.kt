package com.axel.app

import android.content.Context
import android.content.Intent
import android.graphics.Rect
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject

/** Действия на телефоне: приложения, фонарик, нажатия по экрану, таймеры. Вызывается из фонового потока. */
object Phone {
    class Ai(val key: String, val base: String, val models: List<String>)

    fun ai(c: Context): Ai? {
        val pr = c.getSharedPreferences("axel", 0)
        val key = pr.getString("key", "") ?: ""
        val base = pr.getString("base", "") ?: ""
        if (key.isBlank() || base.isBlank()) return null
        val models = ArrayList<String>()
        try {
            val a = JSONArray(pr.getString("models", "[]"))
            for (i in 0 until a.length()) models.add(a.getString(i))
        } catch (e: Exception) { }
        if (models.isEmpty()) return null
        return Ai(key, base, models)
    }

    fun start(c: Context, i: Intent): Boolean {
        return try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    fun web(c: Context, url: String) { start(c, Intent(Intent.ACTION_VIEW, Uri.parse(url))) }

    fun settings(c: Context, page: String) {
        if (!start(c, Intent("android.settings.$page"))) start(c, Intent(Settings.ACTION_SETTINGS))
    }

    fun timer(c: Context, sec: Int) {
        start(c, Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, sec)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
    }

    fun alarm(c: Context, h: Int, m: Int) {
        start(c, Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, h)
            .putExtra(AlarmClock.EXTRA_MINUTES, m)
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true))
    }

    fun mediaKey(c: Context, code: Int) {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    /** Статусная строка шага в чат («Смотрю на экран…»). */
    fun status(c: Context, text: String) {
        val pr = c.getSharedPreferences("axel", 0)
        synchronized(this) {
            val arr = try { JSONArray(pr.getString("log", "[]")) } catch (e: Exception) { JSONArray() }
            arr.put(JSONObject().put("status", text))
            pr.edit().putString("log", arr.toString()).apply()
        }
        MainActivity.inst?.ping()
    }

    // ---------- фонарик ----------
    @Volatile private var torchOn = false
    private var torchWatch = false

    fun torch(c: Context, on: Boolean?): Boolean {
        return try {
            val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            if (!torchWatch) {
                torchWatch = true
                cm.registerTorchCallback(object : CameraManager.TorchCallback() {
                    override fun onTorchModeChanged(cameraId: String, enabled: Boolean) { torchOn = enabled }
                }, null)
            }
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return false
            val want = on ?: !torchOn
            cm.setTorchMode(id, want)
            torchOn = want
            true
        } catch (e: Exception) {
            false
        }
    }

    // ---------- поиск и запуск приложений ----------
    private val TR = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ё' to "e", 'ж' to "zh", 'з' to "z",
        'и' to "i", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r",
        'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "h", 'ц' to "c", 'ч' to "ch", 'ш' to "sh", 'щ' to "sh",
        'ъ' to "", 'ы' to "y", 'ь' to "", 'э' to "e", 'ю' to "yu", 'я' to "ya"
    )

    private fun tr(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            val m = TR[ch]
            if (m != null) sb.append(m) else if (ch.isLetterOrDigit()) sb.append(ch)
        }
        return sb.toString()
    }

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val tmp = d[j]
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + (if (a[i - 1] == b[j - 1]) 0 else 1))
                prev = tmp
            }
        }
        return d[b.length]
    }

    private val ALIAS = mapOf(
        "ватсап" to listOf("whatsapp"), "вацап" to listOf("whatsapp"), "вотсап" to listOf("whatsapp"), "ватсапп" to listOf("whatsapp"),
        "ютуб" to listOf("youtube"), "ютьюб" to listOf("youtube"),
        "калькулятор" to listOf("calculator"),
        "камера" to listOf("camera"),
        "галерея" to listOf("gallery", "photos", "фото"),
        "контакты" to listOf("contacts"),
        "телефон" to listOf("phone", "dialer"),
        "часы" to listOf("clock"),
        "календарь" to listOf("calendar"),
        "сообщения" to listOf("messages"),
        "почта" to listOf("gmail", "mail"),
        "карты" to listOf("maps"),
        "браузер" to listOf("chrome", "browser"),
        "музыка" to listOf("music", "spotify"),
        "настройки" to listOf("settings"),
        "плей маркет" to listOf("play store"),
        "гугл плей" to listOf("play store")
    )

    private fun score(q: String, l: String): Int {
        if (q.isEmpty() || l.isEmpty()) return 999
        if (q == l) return 0
        if (q.length >= 3 && (l.startsWith(q) || (l.length >= 3 && q.startsWith(l)))) return 1
        if (q.length >= 3 && l.contains(q)) return 2
        if (l.length >= 3 && q.contains(l)) return 2
        val d = lev(q, l)
        return if (d <= maxOf(2, l.length / 4)) 3 + d else 999
    }

    fun openApp(c: Context, name: String, pkg: String): Boolean {
        val pm = c.packageManager
        if (pkg.isNotBlank()) {
            val li = pm.getLaunchIntentForPackage(pkg)
            if (li != null) return start(c, li)
        }
        val raw = name.trim().lowercase()
        val queries = ArrayList<String>()
        queries.add(tr(raw))
        ALIAS[raw]?.forEach { queries.add(tr(it)) }
        if (queries.all { it.isEmpty() }) return false
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        var bestPkg: String? = null
        var bestScore = 999
        var bestLen = Int.MAX_VALUE
        for (ri in pm.queryIntentActivities(main, 0)) {
            val p = ri.activityInfo.packageName
            if (p == c.packageName) continue
            val l = tr(ri.loadLabel(pm).toString())
            var s = 999
            for (q in queries) s = minOf(s, score(q, l))
            if (s < bestScore || (s == bestScore && l.length < bestLen)) {
                bestScore = s; bestPkg = p; bestLen = l.length
            }
        }
        if (bestPkg == null || bestScore >= 999) return false
        val li = pm.getLaunchIntentForPackage(bestPkg) ?: return false
        return start(c, li)
    }

    // ---------- нажатия по экрану ----------
    @Volatile private var lastTap: Pair<Float, Float>? = null

    fun tapSmart(c: Context, text: String): Pair<Boolean, String> {
        val svc = AlterAccessibilityService.instance
            ?: return Pair(false, "Включите специальные возможности Axel в настройках Android")
        val t = text.trim()
        if (t.isEmpty()) return Pair(false, "Скажите, на что нажать")
        status(c, "Смотрю на экран…")
        val node = svc.findByText(t)
        if (node != null) {
            val r = Rect()
            node.getBoundsInScreen(r)
            status(c, "Нажимаю на $t…")
            if (svc.clickNode(node)) {
                lastTap = Pair(r.exactCenterX(), r.exactCenterY())
                return Pair(true, "Нажимаю «$t»")
            }
        }
        val shot = svc.screenshot() ?: return Pair(false, "Не нашёл «$t» на экране")
        val p = visionFind(c, shot, t) ?: return Pair(false, "Не нашёл «$t» на экране")
        status(c, "Нажимаю на $t…")
        return if (svc.tapAt(p.first, p.second)) {
            lastTap = p
            Pair(true, "Нажимаю «$t»")
        } else Pair(false, "Не получилось нажать")
    }

    fun tapLast(): Boolean {
        val p = lastTap ?: return false
        return AlterAccessibilityService.instance?.tapAt(p.first, p.second) ?: false
    }

    private fun visionFind(c: Context, shot: AlterAccessibilityService.Shot, label: String): Pair<Float, Float>? {
        val ai = ai(c) ?: return null
        val prompt = "На скриншоте телефона найди элемент интерфейса с надписью или значком «$label». " +
            "Ответь ТОЛЬКО JSON: {\"found\":true,\"x\":число,\"y\":число}, где x и y — координаты центра элемента " +
            "в тысячных долях ширины и высоты изображения (от 0 до 1000, точка 0,0 — левый верхний угол). " +
            "Если такого элемента нет — {\"found\":false}."
        val content = JSONArray()
            .put(JSONObject().put("type", "text").put("text", prompt))
            .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64," + shot.b64)))
        val msgs = JSONArray().put(JSONObject().put("role", "user").put("content", content))
        for (m in ai.models.take(2)) {
            val body = JSONObject().put("model", m).put("temperature", 0).put("max_tokens", 120).put("messages", msgs)
            val resp = Net.postJson(ai.base + "/chat/completions", ai.key, body.toString()) ?: continue
            val ans = try {
                JSONObject(resp).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            } catch (e: Exception) { continue }
            val s = ans.indexOf('{')
            val end = ans.lastIndexOf('}')
            if (s < 0 || end <= s) continue
            val o = try { JSONObject(ans.substring(s, end + 1)) } catch (ex: Exception) { continue }
            if (!o.optBoolean("found", false)) return null
            val x = o.optDouble("x", -1.0)
            val y = o.optDouble("y", -1.0)
            if (x < 0 || y < 0) continue
            return Pair(
                (x.coerceIn(0.0, 1000.0) / 1000.0 * shot.w).toFloat(),
                (y.coerceIn(0.0, 1000.0) / 1000.0 * shot.h).toFloat()
            )
        }
        return null
    }

    fun scrollToSync(c: Context, text: String, dir: String): Boolean {
        val svc = AlterAccessibilityService.instance ?: return false
        for (i in 0..7) {
            if (svc.findByText(text) != null) return true
            if (i == 7) break
            svc.swipe(dir, 0.5f)
            Thread.sleep(700)
        }
        return false
    }

    fun searchInApp(c: Context, text: String): Pair<Boolean, String> {
        val svc = AlterAccessibilityService.instance
            ?: return Pair(false, "Включите специальные возможности Axel в настройках Android")
        var field = svc.findEditable()
        if (field == null) {
            val opener = svc.findBest(listOf("поиск", "search", "найти"))
            if (opener != null) {
                svc.clickNode(opener)
                Thread.sleep(800)
                field = svc.findEditable()
            }
        }
        if (field == null) return Pair(false, "Не нашёл строку поиска")
        if (!svc.setText(field, text)) return Pair(false, "Не получилось ввести запрос")
        Thread.sleep(400)
        if (!svc.imeEnter(field)) {
            val btn = svc.findBest(listOf("найти", "поиск", "search"))
            if (btn != null) svc.clickNode(btn)
        }
        return Pair(true, "Ищу «$text»")
    }
}
