package com.axel.app

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.Settings
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject

object Phone {
    private val tr = mapOf('а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ё' to "e", 'ж' to "zh", 'з' to "z", 'и' to "i", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r", 'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "h", 'ц' to "ts", 'ч' to "ch", 'ш' to "sh", 'щ' to "sch", 'ъ' to "", 'ы' to "y", 'ь' to "", 'э' to "e", 'ю' to "yu", 'я' to "ya")
    private val alias = mapOf(
        "ютуб" to "youtube", "ютьюб" to "youtube", "ватсап" to "whatsapp", "вотсап" to "whatsapp", "хром" to "chrome",
        "телеграм" to "telegram", "телега" to "telegram", "вк" to "vk", "вконтакте" to "vk", "гугл" to "google",
        "камера" to "camera", "галерея" to "gallery", "фото" to "photos", "настройки" to "settings",
        "калькулятор" to "calculator", "часы" to "clock", "календарь" to "calendar", "карты" to "maps",
        "почта" to "gmail", "браузер" to "chrome", "плей маркет" to "play store", "тикток" to "tiktok",
        "инстаграм" to "instagram", "дискорд" to "discord", "твич" to "twitch", "стим" to "steam",
        "телефон" to "phone", "сообщения" to "messages", "спотифай" to "spotify", "нетфликс" to "netflix",
        "майнкрафт" to "minecraft", "роблокс" to "roblox", "браул старс" to "brawl stars", "бравл старс" to "brawl stars",
        "бравл" to "brawl stars", "браво старс" to "brawl stars", "яндекс" to "yandex", "сбер" to "sber",
        "едгар" to "edgar", "эдгар" to "edgar"
    )

    private fun norm(s: String) = s.lowercase().filter { it.isLetterOrDigit() }
    private fun lat(s: String) = norm(s).map { tr[it] ?: it.toString() }.joinToString("")

    private fun lev(a: String, b: String): Int {
        val d = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = d[0]
            d[0] = i
            for (j in 1..b.length) {
                val t = d[j]
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + cost)
                prev = t
            }
        }
        return d[b.length]
    }

    fun start(c: Context, i: Intent): Boolean = try {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val host: Context = AlterAccessibilityService.instance ?: c
        host.startActivity(i)
        true
    } catch (e: Exception) { false }

    fun findApp(c: Context, name: String): String? {
        val q0 = alias[name.lowercase().trim()] ?: name
        val q1 = norm(q0)
        val q2 = lat(q0)
        if (q1.isEmpty()) return null
        val pm = c.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        var best: String? = null
        var bestScore = 1.0
        for (ri in apps) {
            val label = ri.loadLabel(pm).toString()
            val l1 = norm(label)
            val l2 = lat(label)
            if (l1.isEmpty()) continue
            var s = minOf(lev(l1, q1).toDouble() / maxOf(l1.length, q1.length), lev(l2, q2).toDouble() / maxOf(l2.length, q2.length, 1))
            if (q2.length >= 3 && (l2.contains(q2) || l1.contains(q1))) s = minOf(s, 0.1)
            if (s < bestScore) { bestScore = s; best = ri.activityInfo.packageName }
        }
        return if (bestScore <= 0.38) best else null
    }

    /** Тихий запуск приложения: без Toast и системных плашек. */
    fun openApp(c: Context, name: String, pkg: String): Boolean {
        val pm = c.packageManager
        var p: String? = if (pkg.isNotBlank() && pm.getLaunchIntentForPackage(pkg) != null) pkg else null
        if (p == null) p = findApp(c, name)
        val i = (if (p != null) pm.getLaunchIntentForPackage(p) else null) ?: return false
        return start(c, i)
    }

    fun settings(c: Context, page: String) {
        if (!start(c, Intent("android.settings." + page))) start(c, Intent(Settings.ACTION_SETTINGS))
    }

    @Volatile var torchState = false
    private var torchCb: CameraManager.TorchCallback? = null

    /** on = null — переключить. */
    fun torch(c: Context, on: Boolean?): Boolean = try {
        val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        if (torchCb == null) {
            val cb = object : CameraManager.TorchCallback() {
                override fun onTorchModeChanged(id: String, enabled: Boolean) { torchState = enabled }
            }
            torchCb = cb
            cm.registerTorchCallback(cb, Handler(Looper.getMainLooper()))
            Thread.sleep(300)
        }
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
        if (id == null) false else { cm.setTorchMode(id, on ?: !torchState); true }
    } catch (e: Exception) { false }

    fun timer(c: Context, sec: Int) {
        start(c, Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, sec).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
    }

    fun alarm(c: Context, h: Int, m: Int) {
        start(c, Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m).putExtra(AlarmClock.EXTRA_SKIP_UI, true))
    }

    fun mediaKey(c: Context, code: Int) {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    fun web(c: Context, url: String) { start(c, Intent(Intent.ACTION_VIEW, Uri.parse(url))) }

    class Ai(val key: String, val base: String, val models: List<String>)
    @Volatile var lastX = -1.0
    @Volatile var lastY = -1.0
    @Volatile var lastAt = 0L

    fun ai(c: Context): Ai? {
        val pr = c.getSharedPreferences("axel", 0)
        val key = pr.getString("key", "") ?: ""
        val base = pr.getString("base", "") ?: ""
        if (key.isEmpty() || base.isEmpty()) return null
        val all = ArrayList<String>()
        try { val a = JSONArray(pr.getString("models", "[]")); for (i in 0 until a.length()) all.add(a.getString(i)) } catch (e: Exception) { }
        return Ai(key, base, all)
    }

    // ---------- скрытые скриншоты: кэш последнего кадра на 4 секунды ----------

    @Volatile private var cacheBmp: Bitmap? = null
    @Volatile private var cacheAt = 0L

    /** Скрытый кадр экрана в реальном разрешении, с кэшем 3–5 с. Только в памяти. */
    fun shotCached(svc: AlterAccessibilityService, maxAgeMs: Long = 4000L): Bitmap? {
        val b = cacheBmp
        if (b != null && System.currentTimeMillis() - cacheAt < maxAgeMs) return b
        val fresh = svc.shotSync() ?: return b
        cacheBmp = fresh
        cacheAt = System.currentTimeMillis()
        return fresh
    }

    fun invalidateShot() { cacheBmp = null }

    /** Высота статус-бара: передаётся в Vision-модель, чтобы координаты не путались с верхней полосой экрана. */
    fun statusBarPx(svc: AlterAccessibilityService): Int = try {
        val id = svc.resources.getIdentifier("status_bar_height", "dimen", "android")
        if (id > 0) svc.resources.getDimensionPixelSize(id) else 0
    } catch (e: Exception) { 0 }

    /** Статус шага в чат («Смотрю на экран…», «Нажимаю на Бойцы…») — без скриншотов. */
    fun status(c: Context, msg: String) {
        val pr = c.getSharedPreferences("axel", 0)
        val arr = try { JSONArray(pr.getString("log", "[]")) } catch (e: Exception) { JSONArray() }
        arr.put(JSONObject(mapOf("status" to msg)))
        val trimmed = JSONArray()
        for (i in maxOf(0, arr.length() - 50) until arr.length()) trimmed.put(arr.get(i))
        pr.edit().putString("log", trimmed.toString()).apply()
        MainActivity.inst?.ping()
    }

    // ---------- многошаговое зрение: цикл до 7 шагов подряд ----------

    /**
     * Находит и нажимает элемент «text» даже в играх. До 7 шагов:
     * 1) быстрый поиск через доступность; 2) скрытый скриншот (кэш 3–5 с, JPEG 80%,
     * реальное разрешение в промпте) -> Vision-модель -> клик по центру в физических
     * пикселях; если цели нет — ответ {"status":"scroll"} -> плавный свайп, пауза 0.8 с, повтор.
     */
    fun tapSmart(c: Context, text: String): Pair<Boolean, String> {
        val s = AlterAccessibilityService.instance ?: return Pair(false, "Включите специальные возможности Axel в настройках Android")
        val ai = ai(c) ?: return Pair(false, "Не нашёл «$text» на экране, а ключ ИИ для поиска по картинке не указан")
        status(c, "Смотрю на экран…")
        for (step in 0 until 7) {
            // быстрый путь: текстовая кнопка видна системе доступности
            val node = s.findNode(text)
            if (node != null) {
                status(c, "Нажимаю на «$text»…")
                val ok = s.tap(text).first
                if (ok) { lastAt = System.currentTimeMillis(); return Pair(true, "Нажимаю «$text»") }
            }
            val bmp = shotCached(s) ?: return Pair(false, "Не получилось сделать скрытый снимок экрана — возможно, на этом телефоне версия Android ниже 11")
            val (w, h) = s.screenSize()
            val res = try { Vision.locate(ai.base, ai.key, ai.models, bmp, text, statusBarPx(s)) } catch (e: Exception) { Vision.Res.Miss }
            when (res) {
                is Vision.Res.Found -> {
                    val x = res.x.coerceIn(2, w - 3).toDouble()
                    val y = res.y.coerceIn(2, h - 3).toDouble()
                    status(c, "Нажимаю на «$text»…")
                    lastX = x; lastY = y; lastAt = System.currentTimeMillis()
                    invalidateShot()
                    return if (s.tapAt(x, y)) Pair(true, "Нажимаю «$text»") else Pair(false, "Нашёл «$text», но не получилось нажать")
                }
                is Vision.Res.Scroll -> {
                    status(c, "Листаю список…")
                    invalidateShot()
                    s.swipe(res.dir, 0.5f)
                    Thread.sleep(800)
                }
                else -> { }
            }
        }
        return Pair(false, "Не вижу «$text» на экране: кнопка не найдена ни по тексту, ни по скрытому снимку за семь шагов. Проверьте, что кнопка видна, или подключите модель с поддержкой картинок (например, Google Gemini)")
    }

    /** Листать, пока элемент не появится (до 7 раз, скрытые скриншоты с кэшем). */
    fun scrollToSync(c: Context, desc: String, dir: String): Boolean {
        val s = AlterAccessibilityService.instance ?: return false
        val ai = ai(c)
        status(c, "Ищу «$desc»…")
        for (i in 0 until 7) {
            if (s.findNode(desc) != null) return true
            if (ai != null) {
                val bmp = shotCached(s) ?: return false
                val (w, h) = s.screenSize()
                val r = try { Vision.locate(ai.base, ai.key, ai.models, bmp, desc, statusBarPx(s)) } catch (e: Exception) { Vision.Res.Miss }
                if (r is Vision.Res.Found) {
                    lastX = r.x.coerceIn(2, w - 3).toDouble(); lastY = r.y.coerceIn(2, h - 3).toDouble()
                    lastAt = System.currentTimeMillis()
                    return true
                }
                if (r is Vision.Res.Scroll) { s.swipe(r.dir, 0.5f); Thread.sleep(800); invalidateShot(); continue }
            }
            s.swipe(dir, 0.5f)
            Thread.sleep(1200)
        }
        return false
    }

    /** Поиск внутри любого другого открытого приложения: найти строку поиска -> клик -> вставить текст -> «Поиск». */
    fun searchInApp(c: Context, text: String): Pair<Boolean, String> {
        val s = AlterAccessibilityService.instance ?: return Pair(false, "Включите специальные возможности Axel в настройках Android")
        val field = listOf("поиск", "search", "найти", "найти здесь", "искать", "query", "поискать")
            .mapNotNull { s.findNode(it) }.firstOrNull { it.isEditable || it.isClickable } ?: s.findNode("поиск") ?: s.findNode("search")
        if (field == null) return Pair(false, "Не нашёл строку поиска на экране")
        s.tap("поиск")
        Thread.sleep(700)
        if (!s.typeText(text)) return Pair(false, "Не смог вставить текст в поиск")
        Thread.sleep(600)
        val go = listOf("поиск", "search", "найти", "ввод", "enter", "готово", "done").mapNotNull { s.findNode(it) }.firstOrNull()
        return if (go != null && s.tap(go.text?.toString() ?: "поиск").first) Pair(true, "Ищу «$text»")
        else Pair(true, "Ввёл «$text» в поиск")
    }

    fun tapLast(): Boolean {
        val s = AlterAccessibilityService.instance ?: return false
        if (lastX < 0 || System.currentTimeMillis() - lastAt > 90000) return false
        return s.tapAt(lastX, lastY)
    }
}
