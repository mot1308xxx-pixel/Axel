package com.axel.app

import org.json.JSONObject

/** Быстрый локальный разбор частых команд (без ИИ, мгновенно). null — не понял, отдать ИИ. */
object Commands {
    private val stepSplit = Regex(
        "\\s*[,.]?\\s*(?:а потом|а затем|потом|затем|после этого)\\s+" +
        "|\\s*[,;]\\s*(?=нажми|кликни|тапни|ткни|жми|тыкни|открой|запусти|зайди|включи|выключи|листай|пролистай|прокрути|выбери|найди|вбей|напиши|поставь|сделай|выйди|вернись|сверни|закрой)" +
        "|\\s+и (?=нажми|открой|запусти|зайди|листай|пролистай|прокрути|выбери|включи|выключи|найди|вбей|напиши|назад|домой|выйди|вернись|сверни|закрой|тапни|кликни)"
    )
    private val OFF = Regex("выключ|выруб|отключ|погаси|потуши|останов|убери|закрой|деактив")
    private val ONW = Regex("включ|вруб|активир|запусти|поставь|разреши|переключ|открой")

    private fun j(vararg p: Pair<String, Any?>): JSONObject { val o = JSONObject(); p.forEach { o.put(it.first, it.second) }; return o }
    private fun has(t: String, re: String) = Regex(re).containsMatchIn(t)
    private fun one(o: JSONObject): List<JSONObject> = listOf(o)

    private val TOG = listOf(
        Regex("фонар") to "torch",
        Regex("wi-?fi|вай ?-?фай|вайфай") to "wifi",
        Regex("блют|bluetooth|блутуз") to "bluetooth",
        Regex("мобильн\\w* (данн|интернет|инет|сет)|сотов\\w* (данн|связ)|передач\\w* данных") to "mobile_data",
        Regex("режим\\w* (полета|самолета)|авиарежим|в самолете") to "airplane",
        Regex("автоповорот|авто ?поворот|поворот экрана|автоматическ\\w* поворот") to "rotation",
        Regex("защит\\w* глаз|фильтр синег|ночн\\w* свет|режим\\w* чтения|комфорт\\w* для глаз|защит\\w* зрения|режим\\w* для глаз|для глаз|eye comfort|night light|blue light") to "eye_comfort",
        Regex("не беспокоить") to "dnd",
        Regex("экономи\\w* (заряда|батаре\\w*|энергии)|энергосбережен\\w*") to "battery_saver",
        Regex("точк\\w* доступа|хот ?спот|режим\\w* модема") to "hotspot",
        Regex("nfc|нфс|бесконтактн\\w*") to "nfc",
        Regex("геолокац\\w*|местоположен\\w*|gps|гпс") to "location",
        Regex("темн\\w* (тем\\w*|режим\\w*)") to "dark_mode"
    )

    private val TAP = listOf("нажми на кнопку", "нажми кнопку", "нажми на", "нажми", "тапни на", "тапни", "кликни на", "кликни", "жми на", "жми",
        "ткни в", "ткни на", "ткни", "выбери вкладку", "выбери", "перейди в раздел", "зайди в раздел", "перейди на вкладку", "открой вкладку", "открой раздел")
        .sortedByDescending { it.length }
    private val OPEN = listOf("открой приложение", "запусти приложение", "включи приложение", "запусти игру", "открой игру", "включи игру",
        "открой", "запусти", "зайди в", "зайди на", "перейди в", "включи").sortedByDescending { it.length }

    fun parse(raw: String): List<JSONObject>? {
        val low = raw.lowercase().replace('ё', 'е').trim().replace(Regex("^(?:эй|привет|окей)?[ ,]*(?:аксель|алекс|alter|axel)[ ,.!]*"), "")
        val steps = low.split(stepSplit).map { it.trim().trimEnd('.', '!', '?', ',') }.filter { it.isNotEmpty() }
        if (steps.isEmpty() || steps.size > 7) return null
        val out = ArrayList<JSONObject>()
        for ((i, s) in steps.withIndex()) {
            val a = step(s) ?: return null
            if (i > 0) out.add(j("a" to "wait", "ms" to 600))
            out.addAll(a)
        }
        return out
    }

    private fun step(t: String): List<JSONObject>? {
        val off = OFF.containsMatchIn(t)
        val toggle = has(t, "переключи")
        val want: Boolean? = if (toggle) null else !off
        val big = has(t, "намного|сильно|значительно|очень|гораздо")
        val small = has(t, "чуть|немного|слегка|капельку|чуть-чуть")

        if (has(t, "^(стоп|хватит|замолчи|тихо|молчи|заткнись)$")) return one(j("a" to "stop_speech"))
        if (has(t, "помолчи|не говори|без голоса|замьютись|не озвучивай")) return one(j("a" to "mute", "on" to true))
        if (has(t, "^(говори|включи голос|размьютись|озвучивай)")) return one(j("a" to "mute", "on" to false))
        if (has(t, "^(выключись|отключись|заверши работу|выруби себя)$")) return one(j("a" to "self_off"))

        // информация
        if (has(t, "курс") && has(t, "доллар|евро|юан|рубл|валют|фунт|тенге|гривн|лир|злот|иен|франк|usd|eur")) {
            val cur = ArrayList<String>()
            mapOf("доллар" to "USD", "евро" to "EUR", "юан" to "CNY", "фунт" to "GBP", "тенге" to "KZT", "гривн" to "UAH",
                "иен" to "JPY", "лир" to "TRY", "злот" to "PLN", "франк" to "CHF").forEach { (k, v) -> if (t.contains(k)) cur.add(v) }
            return one(j("a" to "rates", "cur" to (if (cur.isEmpty()) "USD,EUR,CNY" else cur.joinToString(","))))
        }
        if (has(t, "который час|сколько (сейчас )?времени|какое (сегодня )?число|какая (сегодня )?дата|какой (сегодня )?день|что за день")) return one(j("a" to "time"))
        if (has(t, "заряд|процент\\w* батаре|батаре\\w* (сколько|осталось)") && !has(t, "экономи|энергосбер")) return one(j("a" to "battery"))
        Regex("^(?:что такое|кто такой|кто такая|кто такие|расскажи про|расскажи о|что значит)\\s+(.+)").find(t)?.let { return one(j("a" to "wiki", "q" to it.groupValues[1])) }

        // переключатели и фонарик
        for ((re, key) in TOG) {
            if (re.containsMatchIn(t) && !t.contains("настройк") && (off || ONW.containsMatchIn(t))) {
                return if (key == "torch") one(j("a" to "torch", "on" to want)) else one(j("a" to "tile", "name" to key, "on" to want))
            }
        }

        // яркость: по смыслу и синонимам
        if (t.contains("яркост")) {
            Regex("(\\d{1,3})\\s*(%|процент)").find(t)?.let { return one(j("a" to "brightness", "percent" to it.groupValues[1].toInt().coerceIn(1, 100))) }
            return when {
                has(t, "выключи всю|отключи всю|миним|самую низк|ниже некуда") -> one(j("a" to "brightness", "percent" to 3))
                has(t, "максим|на полную|на самую высок|на максимум") -> one(j("a" to "brightness", "percent" to 100))
                has(t, "пополам|на половин") -> one(j("a" to "brightness", "percent" to 50))
                has(t, "пониз|уменьш|убав|меньш|темне|ниже|приглуши|сниз") -> one(j("a" to "brightness", "delta" to (if (big) -40 else if (small) -15 else -20)))
                has(t, "повыс|увелич|приба|больш|ярче|выше|подним|добав") -> one(j("a" to "brightness", "delta" to (if (big) 40 else if (small) 18 else 20)))
                else -> null
            }
        }

        // громкость
        if (has(t, "громк|звук|громч|тише|потише")) {
            Regex("(\\d{1,3})\\s*(%|процент)").find(t)?.let { return one(j("a" to "volume", "percent" to it.groupValues[1].toInt())) }
            val stepV = if (big) 30 else if (small) 8 else 15
            return when {
                has(t, "без звука|выключи звук|отключи звук|убери звук|замьют|mute") -> one(j("a" to "volume", "percent" to 0))
                has(t, "включи звук|верни звук") -> one(j("a" to "volume", "percent" to 50))
                has(t, "максим|на полную") -> one(j("a" to "volume", "percent" to 100))
                has(t, "миним") -> one(j("a" to "volume", "percent" to 5))
                has(t, "громч|прибав|увелич|повыс|подним|больш") -> one(j("a" to "volume", "delta" to stepV))
                has(t, "тише|потише|убав|уменьш|пониз|меньш|сниз") -> one(j("a" to "volume", "delta" to -stepV))
                else -> null
            }
        }

        // музыка
        if (has(t, "следующ\\w* (трек|песн\\w*|композиц\\w*)|переключи (трек|песню)|пропусти (трек|песню)|^скип$|^дальше$")) return one(j("a" to "media", "cmd" to "next"))
        if (has(t, "предыдущ\\w*|прошл\\w* (трек|песн\\w*)|верни (трек|песню)")) return one(j("a" to "media", "cmd" to "prev"))
        if (has(t, "^пауза|на паузу|останови (музыку|воспроизведение|трек|песню|видео)|выключи музыку|выруби музыку")) return one(j("a" to "media", "cmd" to "pause"))
        if (has(t, "включи музыку|продолж\\w* (воспроизведение|музыку)|^плей$|воспроизведи")) return one(j("a" to "media", "cmd" to "play"))

        // системные кнопки
        if (has(t, "^(назад|вернись|вернись назад|нажми назад|кнопка назад)$")) return one(j("a" to "global", "cmd" to "back"))
        if (has(t, "^(выйди|выйти)(\\s+(обратно|из игры|из приложения|отсюда))?$")) return one(j("a" to "global", "cmd" to "back"))
        if (has(t, "^(домой|на главную|на главный экран|на рабочий стол|вернись домой|сверни|сверни приложение)$")) return one(j("a" to "global", "cmd" to "home"))
        if (has(t, "последние приложения|недавние приложения|список приложений|мультизадачност|покажи запущенные")) return one(j("a" to "global", "cmd" to "recents"))
        if (has(t, "шторк|покажи уведомления|открой уведомления")) return one(j("a" to "global", "cmd" to "notifications"))
        if (has(t, "быстрые настройки|центр управления|панель управления")) return one(j("a" to "global", "cmd" to "quick_settings"))
        if (has(t, "скриншот|снимок экрана|сделай скрин|^скрин$")) return one(j("a" to "global", "cmd" to "screenshot"))
        if (has(t, "заблокируй (экран|телефон)|выключи экран|погаси экран")) return one(j("a" to "global", "cmd" to "lock"))
        if (has(t, "меню питания|выключи телефон")) return one(j("a" to "global", "cmd" to "power"))

        // геометрические нажатия по зонам экрана: мгновенно, без ИИ (середина, верх, низ, края)
        if (has(t, "нажми|кликни|тапни|ткни|жми|тыкни|тап")) {
            val zone: Pair<Double, Double>? = when {
                Regex("в центр|на центр").containsMatchIn(t) -> 0.5 to 0.5
                has(t, "середин") && has(t, "экран|дисплей|телефон") -> 0.5 to 0.5
                has(t, "центр экрана") -> 0.5 to 0.5
                has(t, "верхн\\w* (часть|край|поле|половин)|верх экрана|верхушк|самый верх") -> 0.5 to 0.15
                has(t, "нижн\\w* (часть|край|поле|половин)|низ экрана|внизу экрана|самый низ") -> 0.5 to 0.85
                has(t, "лев\\w* (часть|край|поле|половин|сторона)|слева экрана|левее") -> 0.12 to 0.5
                has(t, "прав\\w* (часть|край|поле|половин|сторона)|справа экрана|правее") -> 0.88 to 0.5
                else -> null
            }
            if (zone != null) return one(j("a" to "tap_geo", "x" to zone.first, "y" to zone.second))
        }

        // листание
        if (has(t, "листай|пролистай|прокрути|свайп|скролл|смахни")) {
            val dir = when { t.contains("вверх") -> "up"; t.contains("влево") -> "left"; t.contains("вправо") -> "right"; else -> "down" }
            Regex("(?:листай|пролистай|прокрути|скролль|пролистай)\\s+(?:.*\\s)?до\\s+(.+)").find(t)?.let { return one(j("a" to "scroll_to", "text" to it.groupValues[1].trim(), "dir" to dir)) }
            val times = Regex("(\\d+)\\s*раз").find(t)?.groupValues?.get(1)?.toInt() ?: when { t.contains("дважды") || t.contains("два раза") -> 2; t.contains("три раза") -> 3; else -> 1 }
            return one(j("a" to "swipe", "dir" to dir, "times" to times))
        }

        // таймер, будильник
        Regex("таймер на (\\d+)\\s*(секунд\\w*|минут\\w*|час\\w*)").find(t)?.let {
            val n = it.groupValues[1].toInt()
            val sec = when { it.groupValues[2].startsWith("сек") -> n; it.groupValues[2].startsWith("час") -> n * 3600; else -> n * 60 }
            return one(j("a" to "timer", "seconds" to sec))
        }
        if (has(t, "таймер на полчаса")) return one(j("a" to "timer", "seconds" to 1800))
        Regex("будильник на (\\d{1,2})(?:[: ](\\d{2}))?").find(t)?.let {
            val hh = it.groupValues[1].toInt(); val mm = it.groupValues[2].ifEmpty { "0" }.toInt()
            if (hh in 0..23 && mm in 0..59) return one(j("a" to "alarm", "hour" to hh, "minute" to mm))
        }

        // поиск: прямые адреса YouTube / Яндекса / Google и синонимы
        Regex("(?:на|в) (?:ютуб\\w*|youtube)\\s+(?:найди\\s+|напиши\\s+|вбей\\s+|загугли\\s+)?(.+)").find(t)?.let { return one(j("a" to "youtube", "q" to it.groupValues[1])) }
        Regex("(?:в|на) яндекс\\w*\\s+(?:найди\\s+|напиши\\s+|вбей\\s+|загугли\\s+)?(.+)|(?:найди в яндексе)\\s+(.+)").find(t)?.let { return one(j("a" to "yandex", "q" to it.groupValues[1].ifBlank { it.groupValues[2] })) }
        Regex("(?:на карте|маршрут до|как доехать до|проложи маршрут до)\\s*(.+)").find(t)?.let { return one(j("a" to "map", "q" to it.groupValues[1])) }
        Regex("^(?:найди в интернете|найди в гугле|найди в google|загугли|погугли|поищи в интернете|поищи в гугле|найди в сети)\\s+(.+)").find(t)?.let { return one(j("a" to "search", "q" to it.groupValues[1])) }

        // поиск внутри любого открытого приложения: «вбей в поиск …», «напиши в поиске …»
        Regex("^(?:вбей в поиск|вбей в строку поиска|напиши в поиске|введи в поиск|впиши в поиск)\\s+(.+)").find(t)?.let { return one(j("a" to "search_in_app", "text" to it.groupValues[1])) }

        // генерация картинок по синонимам
        Regex("^(?:нарисуй|сгенерируй|сгенерь|сделай фото|сделай картинку|сделай изображение|создай картинку|imagine)\\s+(.+)").find(t)?.let { return one(j("a" to "gen_image", "q" to it.groupValues[1])) }

        // ввод текста
        Regex("^(?:напиши|введи|набери)\\s+(.+)").find(t)?.let { return one(j("a" to "type_text", "text" to it.groupValues[1])) }

        // нажатия
        for (p in TAP) {
            if (t.startsWith("$p ")) {
                val full = t.removePrefix(p).trim()
                val label = full.split(Regex("[,.]| на ней | на нем | где | которая | который | с изображением ")).first().trim().trim('«', '»', '"', '\'')
                    .removeSuffix(" пожалуйста").removeSuffix(" пожалуйста")
                if (label.isEmpty() || label.length > 80) return null
                if (Regex("^(него|нее|ее|этого|эту|это|его)$").matches(label)) return one(j("a" to "tap", "last" to true))
                return one(j("a" to "tap", "text" to label))
            }
        }

        // открыть приложение / настройки
        for (p in OPEN) {
            if (t.startsWith("$p ")) {
                val name = t.removePrefix(p).trim().trim('«', '»', '"')
                if (name.isEmpty()) return null
                if (name.startsWith("настройк") || has(name, "wi-?fi|вай ?-?фай|блют|bluetooth|яркост|экран|дисплей|звук|батаре")) {
                    val page = when {
                        has(name, "wi-?fi|вай ?-?фай") -> "wifi"; has(name, "блют|bluetooth") -> "bluetooth"; has(name, "яркост|экран|дисплей") -> "display"
                        has(name, "звук") -> "sound"; has(name, "батаре") -> "battery"; else -> "main"
                    }
                    return one(j("a" to "settings", "page" to page))
                }
                return one(j("a" to "open_app", "name" to name))
            }
        }
        return null
    }
}
