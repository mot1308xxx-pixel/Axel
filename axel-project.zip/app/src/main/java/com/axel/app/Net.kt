package com.axel.app

import java.net.HttpURLConnection
import java.net.URL

/** Простые HTTP-запросы (вызываются из фонового потока). */
object Net {
    fun get(url: String, timeout: Int = 10000): String? {
        return try {
            val con = URL(url).openConnection() as HttpURLConnection
            con.requestMethod = "GET"
            con.connectTimeout = timeout
            con.readTimeout = timeout
            con.setRequestProperty("User-Agent", "Axel/3.0 (Android)")
            if (con.responseCode !in 200..299) null
            else con.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            null
        }
    }

    fun postJson(url: String, key: String, body: String, timeout: Int = 30000): String? {
        return try {
            val con = URL(url).openConnection() as HttpURLConnection
            con.requestMethod = "POST"
            con.connectTimeout = 10000
            con.readTimeout = timeout
            con.doOutput = true
            con.setRequestProperty("Content-Type", "application/json")
            con.setRequestProperty("Authorization", "Bearer $key")
            con.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            if (con.responseCode !in 200..299) null
            else con.inputStream.bufferedReader().use { it.readText() }
        } catch (e: Exception) {
            null
        }
    }
}
