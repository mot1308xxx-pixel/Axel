package com.axel.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Мозг Axel: быстрый локальный разбор -> иначе ИИ -> исполнение действий. */
object Brain {
    class Reply(val say: String, val labels: List<String>)
    private val voiceHist = ArrayList<Pair<String, String>>()

    fun json(r: Reply): JSONObject = JSONObject().put("say", r.say).put("labels", JSONArray(r.labels))

    private val SYS = """Твоё имя — Axel (мужской род). Ни при каких обстоятельствах не называй себя Gemini, Gemma, Grok, ChatGPT, Claude или другой моделью — ты исключительно Axel. Общайся нормально, живо, современно и естественно, как умный дружелюбный собеседник и личный помощник. Отвечай развёрнуто и по делу, когда это нужно, и не обрубай мысли.
Ты Axel — голосовой ассистент, который УПРАВЛЯЕТ телефоном Android. Отвечай ТОЛЬКО одним JSON-объектом без markdown: {"say":"фраза для озвучки","actions":[...]}.
ПРАВИЛА:
1. Если просят что-то сделать на телефоне — ВСЕГДА делай это через actions. Никогда не объясняй, как сделать это самому, и не отправляй в настройки. Все разрешения у тебя уже есть.
2. Для СЛОЖНЫХ составных запросов («зайди в Brawl Stars, нажми на кнопку магазин и выйди обратно») возвращай МАССИВ действий по порядку: open_app -> {"a":"wait","ms":3000} -> tap -> {"a":"global","cmd":"back"}. В open_app.name передавай ТОЛЬКО название приложения, а не всю фразу целиком.
3. tap сам найдёт кнопку по тексту или по скрытому скриншоту (даже в играх). В text пиши то, что видит пользователь на кнопке, без слов «кнопка» и «нажми».
4. Для курса валют, погоды, времени, заряда и справки используй rates/weather/time/battery/wiki и оставь say пустым: результат озвучит приложение. Для погоды нужен город в именительном падеже (Москва). Остальные вопросы и разговор — отвечай сам в say: живо, интересно и по делу, можно развёрнуто, если вопрос этого требует. Без markdown и эмодзи.
5. Для поиска в интернете: ютуб — youtube{q}, Яндекс — yandex{q}, Google или «загугли» — search{q}, поиск внутри открытого приложения — search_in_app{text}.
6. Не отправляй в Google, если пользователь явно не просил открыть поиск.
7. Если действие невозможно — честно объясни в say, что именно не получилось и почему.
ДЕЙСТВИЯ (поле a):
open_app{name,pkg?}; torch{on:true|false|null}; tile{name:wifi|bluetooth|mobile_data|airplane|rotation|eye_comfort|dnd|battery_saver|hotspot|nfc|location|dark_mode,on:true|false|null};
brightness{percent}|{delta}; volume{percent}|{delta,stream?:music|ring|alarm}; media{cmd:play|pause|next|prev};
global{cmd:back|home|recents|notifications|quick_settings|screenshot|lock|power}; swipe{dir:up|down|left|right,times?}; scroll_to{text,dir?}; tap{text}; tap_geo{x,y}; type_text{text}; wait{ms};
timer{minutes|seconds}; alarm{hour,minute}; settings{page:wifi|bluetooth|display|sound|battery|location|apps|airplane|nfc|date|accessibility|storage|main};
youtube{q}; yandex{q}; map{q}; search{q}; search_in_app{text}; open_url{url}; camera{}; call{number}; sms{number,text}; mute{on}; stop_speech{}; gen_image{q};
rates{cur:"USD,EUR"}; weather{city}; wiki{q}; time{}; battery{}."""

    /** Запасная модель: на неё автоматически повторяется запрос, если основная вернула пусто/null. */
    const val FALLBACK_MODEL = "google/gemma-4-26b-a4b-it:free"

    /** Последняя ошибка сервера — показывается пользователю вместо «Не получилось связаться». */
    @Volatile var lastNetErr: String? = null

    /** Стоимость последнего запроса для шкалы лимитов (0 — локальная команда, 1 — текст, 3 — зрение/картинка). */
    @Volatile var lastCost = 0

    /** Никогда не превращаем JSON null в строку "null": только настоящая непустая строка. */
    private fun cleanText(s: String?): String? {
        val t = s?.trim() ?: return null
        if (t.isEmpty()) return null
        if (t.equals("null", true) || t.equals("undefined", true)) return null
        return t
    }

    /** content -> reasoning/reasoning_content; в Android JSON null превращается в строку "null" — проверяем isNull! */
    fun extractContent(msg: JSONObject): String? {
        if (!msg.isNull("content")) {
            val c = msg.opt("content")
            if (c is String) cleanText(c)?.let { return it }
            if (c is JSONArray) {
                val sb = StringBuilder()
                for (i in 0 until c.length()) {
                    val p = c.optJSONObject(i) ?: continue
                    if (!p.isNull("text")) sb.append(p.optString("text"))
                }
                cleanText(sb.toString())?.let { return it }
            }
        }
        for (k in listOf("reasoning", "reasoning_content")) {
            if (!msg.isNull(k)) cleanText(msg.optString(k))?.let { return it }
        }
        return null
    }

    private fun readErr(con: HttpURLConnection): String? = try {
        con.errorStream?.bufferedReader()?.readText()?.replace(Regex("\\s+"), " ")?.take(300)
    } catch (e: Exception) { null }

    /** POST к ИИ-провайдеру: OpenRouter (chat/completions) или Google Gemini (generateContent с ?key=). */
    private fun post(ai: Phone.Ai, model: String, body: JSONObject): String? {
        val gemini = ai.base.contains("generativelanguage")
        val url = if (gemini) ai.base + "/models/" + model + ":generateContent?key=" + ai.key else ai.base + "/chat/completions"
        val con = URL(url).openConnection() as HttpURLConnection
        con.requestMethod = "POST"
        con.connectTimeout = 8000
        con.readTimeout = 40000
        con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json")
        if (!gemini) con.setRequestProperty("Authorization", "Bearer " + ai.key)
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        if (con.responseCode == 429) { lastNetErr = "Ошибка (429): лимит запросов исчерпан, попробуйте позже"; return null }
        if (con.responseCode !in 200..299) {
            val et = readErr(con)
            lastNetErr = "Ошибка (" + con.responseCode + ")" + (if (!et.isNullOrBlank()) ": " + et else "")
            return null
        }
        val resp = con.inputStream.bufferedReader().readText()
        val j = JSONObject(resp)
        return if (gemini) {
            val cand = j.optJSONArray("candidates")?.optJSONObject(0) ?: return null
            val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: return null
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.optJSONObject(i) ?: continue
                if (!p.isNull("text")) sb.append(p.optString("text"))
            }
            cleanText(sb.toString())
        } else {
            extractContent(j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message") ?: return null)
        }
    }

    private fun chatBody(ai: Phone.Ai, model: String, msgs: JSONArray): JSONObject =
        JSONObject().put("model", model).put("temperature", 0.2).put("max_tokens", 4096).put("messages", msgs)

    private fun geminiBody(ai: Phone.Ai, hist: List<Pair<String, String>>, text: String): JSONObject {
        val contents = JSONArray()
        hist.takeLast(8).forEach {
            contents.put(JSONObject().put("role", if (it.first == "assistant") "model" else "user")
                .put("parts", JSONArray().put(JSONObject().put("text", it.second))))
        }
        contents.put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        return JSONObject().put("contents", contents)
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYS))))
            .put("generationConfig", JSONObject().put("maxOutputTokens", 4096).put("temperature", 0.2))
    }

    private fun llm(ai: Phone.Ai, hist: List<Pair<String, String>>, text: String): String? {
        lastNetErr = null
        val gemini = ai.base.contains("generativelanguage")
        val openrouter = ai.base.contains("openrouter")
        val own = ai.models.filter { it.isNotBlank() }
        // основная -> запасная VL -> запасная gemma: пустой или null-ответ автоматически повторяется
        val models = if (gemini) {
            (own + listOf("gemini-2.5-flash")).distinct().take(3)
        } else {
            (own + listOf("nvidia/nemotron-3.5-super-vl:free", FALLBACK_MODEL)).distinct().take(5)
        }
        // OpenRouter: модели gemma отклоняют отдельную {role:"system"} с 400 — системный промпт Axel кладём в первое user-сообщение
        val msgs = JSONArray()
        if (!gemini && !openrouter) msgs.put(JSONObject().put("role", "system").put("content", SYS))
        hist.takeLast(8).forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        msgs.put(JSONObject().put("role", "user").put("content", text))
        if (!gemini && openrouter) {
            for (i in 0 until msgs.length()) {
                val o = msgs.optJSONObject(i)
                if (o != null && o.optString("role") == "user") {
                    o.put("content", SYS + "\n\n" + o.optString("content", "")); break
                }
            }
        }
        for (attempt in 0..1) {
            for (m in models) {
                try {
                    val body = if (gemini) geminiBody(ai, hist, text) else chatBody(ai, m, msgs)
                    val ans = post(ai, m, body) ?: continue
                    return ans
                } catch (e: Exception) { }
            }
            // повторная попытка при кратковременном сбое сети
            Thread.sleep(1200)
        }
        return null
    }

    private fun parse(ans: String): Pair<String, List<JSONObject>> {
        // лишний текст вокруг JSON не ломает парсер: берём от первой { до последней }
        val json = Regex("\\{[\\s\\S]*\\}").find(ans)?.value ?: ans
        val s = json.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val i = s.indexOf('{')
        val j = s.lastIndexOf('}')
        if (i >= 0 && j > i) {
            try {
                val o = JSONObject(s.substring(i, j + 1))
                val arr = o.optJSONArray("actions")
                val acts = ArrayList<JSONObject>()
                if (arr != null) for (k in 0 until arr.length()) arr.optJSONObject(k)?.let { acts.add(it) }
                return Pair(cleanText(o.optString("say", "")) ?: "", acts)
            } catch (e: Exception) { }
        }
        return Pair(cleanText(ans) ?: "", emptyList())
    }

    /** Списание лимита: копится в SharedPreferences, MainActivity транслирует его в window.onApiRequestCompleted. */
    private fun charge(c: Context, cost: Int) {
        if (cost <= 0) return
        val pr = c.getSharedPreferences("axel", 0)
        pr.edit().putInt("pendingCost", pr.getInt("pendingCost", 0) + cost).apply()
        MainActivity.inst?.ping()
    }

    /** hist == null — голосовая команда из фона (история хранится здесь). */
    fun handle(c: Context, text: String, hist: List<Pair<String, String>>?): Reply {
        lastCost = 0
        val h = hist ?: voiceHist
        val local = Commands.parse(text)
        val say0: String
        val acts: List<JSONObject>
        if (local != null) { say0 = ""; acts = local }
        else {
            val ai = Phone.ai(c) ?: return Reply("Чтобы я понимал сложные команды, вставьте API-ключ в настройках Axel.", emptyList())
            val ans = llm(ai, h, text) ?: return Reply(lastNetErr ?: "Не получилось связаться с ИИ. Проверьте интернет и ключ.", emptyList())
            val p = parse(ans)
            if (p.first.isEmpty() && p.second.isEmpty()) {
                // модель вернула пустоту — повтор на запасной модели уже был; честно сообщаем
                return Reply("Модель вернула пустой ответ. Попробуйте спросить ещё раз или переключите провайдера в настройках.", emptyList())
            }
            say0 = p.first; acts = p.second
            // текстовый ответ — 1 единица (2%), зрение/картинка — 3 единицы (6%)
            val vision = acts.any { it.optString("a") in setOf("tap", "tap_geo", "gen_image", "scroll_to", "search_in_app") }
            lastCost = if (vision) 3 else 1
            charge(c, lastCost)
        }
        val res = if (acts.isEmpty()) emptyList() else Actions.runAll(c, acts)
        val fail = res.firstOrNull { !it.ok }
        val infos = res.filter { it.info && it.ok }.map { it.msg }
        val say = when {
            fail != null -> fail.msg
            infos.isNotEmpty() -> (if (say0.isNotBlank()) "$say0. " else "") + infos.joinToString(". ")
            say0.isNotBlank() -> say0
            res.isNotEmpty() -> res.map { it.msg }.filter { it.isNotBlank() }.joinToString(". ")
            else -> "Не понял, повторите."
        }
        val labels = res.filter { !it.info && it.msg.isNotBlank() }.map { it.msg }
        if (hist == null) {
            voiceHist.add("user" to text); voiceHist.add("assistant" to say)
            while (voiceHist.size > 12) voiceHist.removeAt(0)
        }
        return Reply(say, labels)
    }

    /** Записать обмен в историю чата (показывается при открытии приложения). */
    fun log(c: Context, user: String, r: Reply) {
        val pr = c.getSharedPreferences("axel", 0)
        val arr = try { JSONArray(pr.getString("log", "[]")) } catch (e: Exception) { JSONArray() }
        arr.put(JSONObject().put("u", user).put("r", json(r)))
        val trimmed = JSONArray()
        for (i in maxOf(0, arr.length() - 50) until arr.length()) trimmed.put(arr.get(i))
        pr.edit().putString("log", trimmed.toString()).apply()
        MainActivity.inst?.ping()
    }
}
