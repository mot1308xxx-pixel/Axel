package com.axel.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Озвучка ответов встроенным синтезатором речи телефона. */
object Speaker {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile var speaking = false
    @Volatile var rate = 1.0f
    private val callbacks = ConcurrentHashMap<String, () -> Unit>()
    private val queue = ArrayList<Pair<String, String>>()
    private var counter = 0

    private fun pr(c: Context) = c.getSharedPreferences("axel", 0)
    fun muted(c: Context): Boolean = pr(c).getBoolean("muted", false)
    fun setMuted(c: Context, m: Boolean) {
        pr(c).edit().putBoolean("muted", m).apply()
        if (m) stop()
    }
    fun langTag(c: Context): String = pr(c).getString("lang", "ru-RU") ?: "ru-RU"
    fun setLang(c: Context, tag: String) {
        pr(c).edit().putString("lang", tag).apply()
        applyLang(c)
    }

    @Synchronized
    fun init(c: Context) {
        if (tts != null) return
        val app = c.applicationContext
        tts = TextToSpeech(app) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { speaking = true }
                    override fun onDone(id: String?) {
                        speaking = false
                        if (id != null) callbacks.remove(id)?.invoke()
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) {
                        speaking = false
                        if (id != null) callbacks.remove(id)?.invoke()
                    }
                    override fun onError(id: String?, errorCode: Int) {
                        speaking = false
                        if (id != null) callbacks.remove(id)?.invoke()
                    }
                })
                ready = true
                applyLang(app)
                flush()
            }
        }
    }

    private fun applyLang(c: Context) {
        val t = tts ?: return
        if (!ready) return
        try {
            val loc = Locale.forLanguageTag(langTag(c))
            t.setLanguage(loc)
            t.setPitch(0.9f)
            val voices = t.voices?.filter { it.locale.language == loc.language } ?: emptyList()
            val male = voices.firstOrNull {
                val n = it.name.lowercase()
                n.contains("male") && !n.contains("female")
            }
            if (male != null) t.voice = male
        } catch (e: Exception) { }
    }

    private fun flush() {
        val t = tts ?: return
        val items = synchronized(queue) { val l = ArrayList(queue); queue.clear(); l }
        for (it in items) speakNow(t, it.first, it.second)
    }

    private fun speakNow(t: TextToSpeech, id: String, text: String) {
        try {
            for (k in callbacks.keys.toList()) if (k != id) callbacks.remove(k)
            t.setSpeechRate(rate)
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        } catch (e: Exception) {
            callbacks.remove(id)?.invoke()
        }
    }

    fun say(c: Context, text: String, done: (() -> Unit)? = null) {
        init(c)
        val clean = text.trim().take(3500)
        if (clean.isEmpty() || muted(c)) { done?.invoke(); return }
        val id: String
        synchronized(this) { counter++; id = "u$counter" }
        if (done != null) callbacks[id] = done
        val t = tts
        if (t == null || !ready) {
            synchronized(queue) { queue.add(Pair(id, clean)) }
            return
        }
        speakNow(t, id, clean)
    }

    fun stop() {
        callbacks.clear()
        synchronized(queue) { queue.clear() }
        speaking = false
        try { tts?.stop() } catch (e: Exception) { }
    }
}
