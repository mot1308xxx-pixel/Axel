package com.axel.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Единый голос Axel: глубокий мужской тембр (pitch 0.82, rate 1.05) или нейроголос ru-RU-DmitryNeural (Edge TTS, бесплатно). */
object Speaker {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var pending: String? = null
    private val dones = HashMap<String, () -> Unit>()
    @Volatile var speaking = false
    @Volatile var onState: ((Boolean) -> Unit)? = null
    @Volatile private var langTag = "ru-RU"

    private fun prefs(c: Context) = c.getSharedPreferences("axel", 0)
    fun muted(c: Context) = prefs(c).getBoolean("mute", false)
    fun setMuted(c: Context, m: Boolean) {
        prefs(c).edit().putBoolean("mute", m).apply()
        if (m) stop()
    }

    /** Движок озвучки: "google" (встроенный TTS с пониженным тембром) или "edge" (нейроголос Dmitry). */
    fun engine(c: Context): String = prefs(c).getString("voiceEngine", "google") ?: "google"
    fun setEngine(c: Context, e: String) {
        prefs(c).edit().putString("voiceEngine", if (e == "edge") "edge" else "google").apply()
        if (e == "edge") stop()
    }

    /** Язык озвучки из настроек (например "ru-RU", "en-US"). */
    fun lang(c: Context): String = prefs(c).getString("lang", "ru-RU") ?: "ru-RU"

    fun setLang(c: Context, tag: String) {
        prefs(c).edit().putString("lang", tag).apply()
        langTag = tag
        applyLang()
    }

    /** Глубокий мужской голос: ищем rud/ruf/male/Dmitry, женские исключаем; pitch 0.82, rate 1.05. */
    private fun applyLang() {
        val t = tts ?: return
        try {
            val loc = Locale.forLanguageTag(langTag)
            t.language = loc
            t.setPitch(0.82f)
            t.setSpeechRate(1.05f)
            val same = try {
                t.voices?.filter { v -> !v.isNetworkConnectionRequired && v.locale.language == loc.language } ?: emptyList()
            } catch (e: Exception) { emptyList() }
            val maleRe = Regex("rud|ruf|male|dmitry", RegexOption.IGNORE_CASE)
            val male = same.filter { maleRe.containsMatchIn(it.name) && !it.name.lowercase().contains("female") && !it.name.lowercase().contains("woman") }
            val pick = if (male.isNotEmpty()) male.maxByOrNull { it.quality }
            else same.maxByOrNull { it.quality }
            if (pick != null) t.voice = pick
        } catch (e: Exception) { }
    }

    fun init(c: Context) {
        langTag = lang(c)
        if (tts != null) { applyLang(); return }
        tts = TextToSpeech(c.applicationContext) { st ->
            ready = st == TextToSpeech.SUCCESS
            if (ready) {
                applyLang()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { set(true) }
                    override fun onDone(id: String?) { fin(id) }
                    override fun onError(id: String?) { fin(id) }
                })
                pending?.let { p -> pending = null; tts?.speak(p, TextToSpeech.QUEUE_FLUSH, null, "u0") }
            }
        }
    }

    /** Озвучка: сначала выбранный движок, при сбое — автоматический откат к встроенному TTS. */
    fun say(c: Context, text: String, done: (() -> Unit)? = null) {
        if (muted(c) || text.isBlank()) { done?.invoke(); return }
        init(c)
        val t = text.replace(Regex("[*_`#>]"), "").take(1500)
        if (engine(c) == "edge") {
            set(true)
            val ok = EdgeTts.synthesize(c, t) { set(false); done?.invoke() }
            if (ok) return
            set(false) // Edge недоступен — говорим встроенным голосом ниже
        }
        if (!ready) { pending = t; done?.invoke(); return }
        val id = "u" + System.nanoTime()
        if (done != null) synchronized(dones) { dones[id] = done }
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private fun fin(id: String?) {
        set(false)
        val d = synchronized(dones) { if (id != null) dones.remove(id) else null }
        d?.invoke()
    }

    private fun set(v: Boolean) { speaking = v; onState?.invoke(v) }
    fun stop() { try { tts?.stop() } catch (e: Exception) { }; EdgeTts.cancel(); set(false) }
}
