package com.axel.app

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Единый голос Axel: мужской, общий для приложения и фоновой службы. */
object Speaker {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    @Volatile private var pending: String? = null
    private val dones = HashMap<String, () -> Unit>()
    @Volatile var speaking = false
    @Volatile var onState: ((Boolean) -> Unit)? = null
    @Volatile private var langTag = "ru-RU"

    fun muted(c: Context) = c.getSharedPreferences("axel", 0).getBoolean("mute", false)
    fun setMuted(c: Context, m: Boolean) {
        c.getSharedPreferences("axel", 0).edit().putBoolean("mute", m).apply()
        if (m) stop()
    }

    /** Язык озвучки из настроек (например "ru-RU", "en-US"). */
    fun lang(c: Context): String = c.getSharedPreferences("axel", 0).getString("lang", "ru-RU") ?: "ru-RU"

    fun setLang(c: Context, tag: String) {
        c.getSharedPreferences("axel", 0).edit().putString("lang", tag).apply()
        langTag = tag
        applyLang()
    }

    /** Полная мужская озвучка: сначала ищем голос с "male" в имени, затем лучшее качество. */
    private fun applyLang() {
        val t = tts ?: return
        try {
            val loc = Locale.forLanguageTag(langTag)
            t.language = loc
            val same = try {
                t.voices?.filter { v -> !v.isNetworkConnectionRequired && v.locale.language == loc.language } ?: emptyList()
            } catch (e: Exception) { emptyList() }
            val male = same.filter { v -> v.name.lowercase().contains("male") && !v.name.lowercase().contains("female") && !v.name.lowercase().contains("woman") }
            val pool = if (same.isNotEmpty()) same else emptyList()
            val pick = (if (male.isNotEmpty()) male else pool).maxByOrNull { it.quality }
            if (pick != null) t.voice = pick
        } catch (e: Exception) { }
    }

    fun init(c: Context) {
        langTag = lang(c)
        if (tts != null) { applyLang(); return }
        tts = TextToSpeech(c.applicationContext) { st ->
            ready = st == TextToSpeech.SUCCESS
            if (ready) {
                applyLang()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { set(true) }
                    override fun onDone(id: String?) { fin(id) }
                    override fun onError(id: String?) { fin(id) }
                })
                pending?.let { p -> pending = null; tts?.speak(p, TextToSpeech.QUEUE_FLUSH, null, "u0") }
            }
        }
    }

    fun say(c: Context, text: String, done: (() -> Unit)? = null) {
        if (muted(c) || text.isBlank()) { done?.invoke(); return }
        init(c)
        val t = text.replace(Regex("[*_`#>]"), "").take(1500)
        if (!ready) { pending = t; done?.invoke(); return }
        val id = "u" + System.nanoTime()
        if (done != null) synchronized(dones) { dones[id] = done }
        tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, id)
    }

    private fun fin(id: String?) {
        set(false)
        val d = synchronized(dones) { if (id != null) dones.remove(id) else null }
        d?.invoke()
    }

    private fun set(v: Boolean) { speaking = v; onState?.invoke(v) }
    fun stop() { try { tts?.stop() } catch (e: Exception) { }; set(false) }
}
