package com.axel.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Мозг Axel: быстрый локальный разбор -> иначе ИИ -> исполнение действий. */
object Brain {
    class Reply(val say: String, val labels: List<String>)
    private val voiceHist = ArrayList<Pair<String, String>>()

    fun json(r: Reply): JSONObject = JSONObject().put("say", r.say).put("labels", JSONArray(r.labels))

    private val SYS = """Твоё имя — Axel (мужской род). Ни при каких обстоятельствах не называй себя Gemini, Gemma, Grok, ChatGPT, Claude или другой моделью — ты исключительно Axel. Отвечай быстро, чётко, вежливо и тактично.
Ты Axel — голосовой ассистент, который УПРАВЛЯЕТ телефоном Android. Отвечай ТОЛЬКО одним JSON-объектом без markdown: {"say":"короткая фраза для озвучки","actions":[...]}.
ПРАВИЛА:
1. Если просят что-то сделать на телефоне — ВСЕГДА делай это через actions. Никогда не объясняй, как сделать это самому, и не отправляй в настройки. Все разрешения у тебя уже есть.
2. Несколько шагов — цепочка действий. Пример: открыть приложение, потом {"a":"wait","ms":3000}, потом tap.
3. tap сам найдёт кнопку по тексту или по скрытому скриншоту (даже в играх). В text пиши то, что видит пользователь на кнопке, без слов «кнопка» и «нажми».
4. Для курса валют, погоды, времени, заряда и справки используй rates/weather/time/battery/wiki и оставь say пустым: результат озвучит приложение. Для погоды нужен город в именительном падеже (Москва). Остальные вопросы и разговор — отвечай сам в say: 1–3 предложения, без markdown, списков и эмодзи.
5. Для поиска в интернете: ютуб — youtube{q}, Яндекс — yandex{q}, Google или «загугли» — search{q}, поиск внутри открытого приложения — search_in_app{text}.
6. Не отправляй в Google, если пользователь явно не просил открыть поиск.
7. Если действие невозможно — коротко и честно скажи об этом в say.
ДЕЙСТВИЯ (поле a):
open_app{name,pkg?}; torch{on:true|false|null}; tile{name:wifi|bluetooth|mobile_data|airplane|rotation|eye_comfort|dnd|battery_saver|hotspot|nfc|location|dark_mode,on:true|false|null};
brightness{percent}|{delta}; volume{percent}|{delta,stream?:music|ring|alarm}; media{cmd:play|pause|next|prev};
global{cmd:back|home|recents|notifications|quick_settings|screenshot|lock|power}; swipe{dir:up|down|left|right,times?}; scroll_to{text,dir?}; tap{text}; type_text{text}; wait{ms};
timer{minutes|seconds}; alarm{hour,minute}; settings{page:wifi|bluetooth|display|sound|battery|location|apps|airplane|nfc|date|accessibility|storage|main};
youtube{q}; yandex{q}; map{q}; search{q}; search_in_app{text}; open_url{url}; camera{}; call{number}; sms{number,text}; mute{on}; stop_speech{}; gen_image{q};
rates{cur:"USD,EUR"}; weather{city}; wiki{q}; time{}; battery{}."""

    /** Последняя ошибка сервера — показывается пользователю вместо «Не получилось связаться». */
    @Volatile var lastNetErr: String? = null

    private fun llm(ai: Phone.Ai, hist: List<Pair<String, String>>, text: String): String? {
        val msgs = JSONArray()
        val openrouter = ai.base.contains("openrouter")
        // OpenRouter: модели gemma часто отклоняют отдельную {role:"system"} с ошибкой 400 —
        // системный промпт Axel кладём внутрь первого user-сообщения.
        if (!openrouter) msgs.put(JSONObject().put("role", "system").put("content", SYS))
        hist.takeLast(8).forEach { msgs.put(JSONObject().put("role", it.first).put("content", it.second)) }
        msgs.put(JSONObject().put("role", "user").put("content", text))
        if (openrouter) {
            for (i in 0 until msgs.length()) {
                val o = msgs.optJSONObject(i)
                if (o != null && o.optString("role") == "user") {
                    o.put("content", SYS + "\n\n" + o.optString("content", "")); break
                }
            }
        }
        for (attempt in 0..1) {
            for (m in ai.models.take(4)) {
                try {
                    val body = JSONObject().put("model", m).put("temperature", 0.2).put("max_tokens", 600).put("messages", msgs)
                    val con = URL(ai.base + "/chat/completions").openConnection() as HttpURLConnection
                    con.requestMethod = "POST"
                    con.connectTimeout = 8000
                    con.readTimeout = 25000
                    con.doOutput = true
                    con.setRequestProperty("Content-Type", "application/json")
                    con.setRequestProperty("Authorization", "Bearer " + ai.key)
                    con.outputStream.use { it.write(body.toString().toByteArray()) }
                    if (con.responseCode == 429) { lastNetErr = "HTTP 429 (лимит исчерпан)"; continue }
                    if (con.responseCode !in 200..299) {
                        // реальный статус и текст ошибки от сервера
                        val et = try { con.errorStream?.bufferedReader()?.readText()?.replace(Regex("\\s+"), " ")?.take(300) } catch (e: Exception) { null }
                        lastNetErr = "Ошибка (" + con.responseCode + ")" + (if (!et.isNullOrBlank()) ": " + et else "")
                        continue
                    }
                    val resp = con.inputStream.bufferedReader().readText()
                    val ans = JSONObject(resp).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                    if (ans.isNotBlank()) return ans
                } catch (e: Exception) { }
            }
            // повторная попытка при кратковременном сбое сети
            Thread.sleep(1200)
        }
        return null
    }

    private fun parse(ans: String): Pair<String, List<JSONObject>> {
        val s = ans.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val i = s.indexOf('{')
        val j = s.lastIndexOf('}')
        if (i >= 0 && j > i) {
            try {
                val o = JSONObject(s.substring(i, j + 1))
                val arr = o.optJSONArray("actions")
                val acts = ArrayList<JSONObject>()
                if (arr != null) for (k in 0 until arr.length()) arr.optJSONObject(k)?.let { acts.add(it) }
                return Pair(o.optString("say", ""), acts)
            } catch (e: Exception) { }
        }
        return Pair(s, emptyList())
    }

    /** hist == null — голосовая команда из фона (история хранится здесь). */
    fun handle(c: Context, text: String, hist: List<Pair<String, String>>?): Reply {
        val h = hist ?: voiceHist
        val local = Commands.parse(text)
        val say0: String
        val acts: List<JSONObject>
        if (local != null) { say0 = ""; acts = local }
        else {
            val ai = Phone.ai(c) ?: return Reply("Чтобы я понимал сложные команды, вставьте API-ключ в настройках Axel.", emptyList())
            val ans = llm(ai, h, text) ?: return Reply(lastNetErr ?: "Не получилось связаться с ИИ. Проверьте интернет и ключ.", emptyList())
            val p = parse(ans)
            say0 = p.first; acts = p.second
        }
        val res = if (acts.isEmpty()) emptyList() else Actions.runAll(c, acts)
        val fail = res.firstOrNull { !it.ok }
        val infos = res.filter { it.info && it.ok }.map { it.msg }
        val say = when {
            fail != null -> fail.msg
            infos.isNotEmpty() -> (if (say0.isNotBlank()) "$say0. " else "") + infos.joinToString(". ")
            say0.isNotBlank() -> say0
            res.isNotEmpty() -> res.map { it.msg }.filter { it.isNotBlank() }.joinToString(". ")
            else -> "Не понял, повторите."
        }
        val labels = res.filter { !it.info && it.msg.isNotBlank() }.map { it.msg }
        if (hist == null) {
            voiceHist.add("user" to text); voiceHist.add("assistant" to say)
            while (voiceHist.size > 12) voiceHist.removeAt(0)
        }
        return Reply(say, labels)
    }

    /** Записать обмен в историю чата (показывается при открытии приложения). */
    fun log(c: Context, user: String, r: Reply) {
        val pr = c.getSharedPreferences("axel", 0)
        val arr = try { JSONArray(pr.getString("log", "[]")) } catch (e: Exception) { JSONArray() }
        arr.put(JSONObject().put("u", user).put("r", json(r)))
        val trimmed = JSONArray()
        for (i in maxOf(0, arr.length() - 50) until arr.length()) trimmed.put(arr.get(i))
        pr.edit().putString("log", trimmed.toString()).apply()
        MainActivity.inst?.ping()
    }
}
