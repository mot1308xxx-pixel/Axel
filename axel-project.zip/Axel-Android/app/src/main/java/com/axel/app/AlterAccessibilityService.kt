package com.axel.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.content.ContextCompat
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Служба специальных возможностей Axel: реальные нажатия dispatchGesture, свайпы, ввод текста
 *  и СКРЫТЫЕ скриншоты (только в оперативной памяти, с кэшем последнего кадра 3–5 секунд). */
class AlterAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: AlterAccessibilityService? = null }
    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun roots(): List<AccessibilityNodeInfo> {
        val r = ArrayList<AccessibilityNodeInfo>()
        try { windows.forEach { w -> w.root?.let { r.add(it) } } } catch (e: Exception) { }
        rootInActiveWindow?.let { r.add(it) }
        return r
    }

    private fun norm(s: String) = s.lowercase().replace('ё', 'е').trim()

    private fun labelOf(n: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        n.text?.let { sb.append(it).append(' ') }
        n.contentDescription?.let { sb.append(it).append(' ') }
        if (Build.VERSION.SDK_INT >= 30) n.stateDescription?.let { sb.append(it) }
        return norm(sb.toString())
    }

    /** Лучший по совпадению видимый элемент с таким текстом. */
    fun findNode(text: String): AccessibilityNodeInfo? {
        val q = norm(text)
        if (q.isEmpty()) return null
        var best: AccessibilityNodeInfo? = null
        var bs = Int.MAX_VALUE
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null) return
            val t = norm((n.text ?: n.contentDescription ?: "").toString())
            if (t.isNotEmpty() && n.isVisibleToUser) {
                val s = when {
                    t == q -> 0
                    t.startsWith(q) || t.endsWith(q) -> 1 + minOf(t.length - q.length, 50)
                    t.contains(q) -> 60 + minOf(t.length - q.length, 100)
                    t.length >= 3 && q.contains(t) -> 200 + (q.length - t.length)
                    else -> Int.MAX_VALUE
                }
                if (s < bs) { bs = s; best = n }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        roots().forEach { walk(it) }
        return best
    }

    private fun clickNode(node: AccessibilityNodeInfo): Boolean {
        var n: AccessibilityNodeInfo? = node
        while (n != null) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            n = n.parent
        }
        val r = Rect(); node.getBoundsInScreen(r)
        return tapAt(r.exactCenterX().toDouble(), r.exactCenterY().toDouble())
    }

    fun tap(text: String): Pair<Boolean, String> {
        val node = findNode(text) ?: return Pair(false, "Не нашёл на экране надпись «$text». В играх кнопки часто не видны системе.")
        val ok = clickNode(node)
        return Pair(ok, if (ok) "Нажал «$text»" else "Не удалось нажать")
    }

    private fun collect(n: AccessibilityNodeInfo?, d: Int, sb: StringBuilder) {
        if (n == null || d > 2) return
        sb.append(' ').append(labelOf(n))
        for (i in 0 until n.childCount) collect(n.getChild(i), d + 1, sb)
    }

    private fun findTile(labels: List<String>): AccessibilityNodeInfo? {
        val rs = roots()
        for (lab in labels) {
            var found: AccessibilityNodeInfo? = null
            fun walk(n: AccessibilityNodeInfo?) {
                if (n == null || found != null) return
                val t = labelOf(n)
                if (t.contains(lab) && !(lab == "интернет" && t.contains("мобильн"))) { found = n; return }
                for (i in 0 until n.childCount) walk(n.getChild(i))
            }
            rs.forEach { walk(it) }
            if (found != null) return found
        }
        return null
    }

    private fun checkedOf(n: AccessibilityNodeInfo): Boolean? {
        var p: AccessibilityNodeInfo? = n
        var d = 0
        while (p != null && d < 4) { if (p.isCheckable) return p.isChecked; p = p.parent; d++ }
        return null
    }

    /** 0 — не нашёл, 1 — переключил, 2 — уже в нужном состоянии. */
    private fun clickTile(n: AccessibilityNodeInfo, on: Boolean?): Int {
        val sb = StringBuilder()
        collect(n, 0, sb)
        var p = n.parent
        var d = 0
        while (p != null && d < 2) { sb.append(' ').append(labelOf(p)); p = p.parent; d++ }
        val s = sb.toString()
        val cur: Boolean? = when {
            Regex("выкл|\\boff\\b|disabled").containsMatchIn(s) -> false
            Regex("вкл|\\bon\\b|enabled").containsMatchIn(s) -> true
            else -> checkedOf(n)
        }
        if (on != null && cur == on) return 2
        clickNode(n)
        return 1
    }

    /** Открывает шторку быстрых настроек и нажимает нужную плитку (защита глаз, Wi-Fi и т. д.). */
    fun toggleTile(labels: List<String>, on: Boolean?): Int {
        performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)
        Thread.sleep(1100)
        var res = 0
        for (attempt in 0..4) {
            val n = findTile(labels)
            if (n != null) { res = clickTile(n, on); break }
            when (attempt) {
                0 -> swipeAbs(0.5f, 0.12f, 0.5f, 0.7f)
                1, 2 -> swipeAbs(0.85f, 0.4f, 0.15f, 0.4f)
                else -> swipeAbs(0.15f, 0.4f, 0.85f, 0.4f)
            }
            Thread.sleep(800)
        }
        Thread.sleep(300)
        performGlobalAction(GLOBAL_ACTION_BACK)
        return res
    }

    fun typeText(t: String): Boolean {
        var f: AccessibilityNodeInfo? = null
        for (r in roots()) { f = r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT); if (f != null) break }
        if (f == null) {
            var ed: AccessibilityNodeInfo? = null
            fun walk(n: AccessibilityNodeInfo?) {
                if (n == null || ed != null) return
                if (n.isEditable && n.isVisibleToUser) { ed = n; return }
                for (i in 0 until n.childCount) walk(n.getChild(i))
            }
            roots().forEach { walk(it) }
            ed?.let { clickNode(it); Thread.sleep(500); f = it }
        }
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) }
        return f?.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b) ?: false
    }

    /** СКРЫТЫЙ снимок экрана: только в оперативной памяти, никакого сохранения и отправки в чат. */
    fun shot(cb: (Bitmap?) -> Unit) {
        if (Build.VERSION.SDK_INT < 30) { cb(null); return }
        takeScreenshot(Display.DEFAULT_DISPLAY, ContextCompat.getMainExecutor(this), object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                val hb = r.hardwareBuffer
                val bmp = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                hb.close()
                cb(bmp)
            }
            override fun onFailure(code: Int) { cb(null) }
        })
    }

    fun tapAt(x: Double, y: Double): Boolean {
        val p = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null)
    }

    private fun swipeAbs(x1: Float, y1: Float, x2: Float, y2: Float): Boolean {
        val m = resources.displayMetrics
        val p = Path().apply { moveTo(m.widthPixels * x1, m.heightPixels * y1); lineTo(m.widthPixels * x2, m.heightPixels * y2) }
        return dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, 350)).build(), null, null)
    }

    /** Плавный свайп в направлении dir (down = контент уезжает вверх, список листается вниз). */
    fun swipe(dir: String, frac: Float = 0.5f): Boolean {
        val a = 0.5f + frac / 2
        val b = 0.5f - frac / 2
        return when (dir) {
            "down" -> swipeAbs(0.5f, a, 0.5f, b)
            "up" -> swipeAbs(0.5f, b, 0.5f, a)
            "left" -> swipeAbs(a, 0.5f, b, 0.5f)
            else -> swipeAbs(b, 0.5f, a, 0.5f)
        }
    }

    /** Реальное разрешение экрана устройства в пикселях. */
    fun screenSize(): Pair<Int, Int> {
        val m = resources.displayMetrics
        return Pair(m.widthPixels, m.heightPixels)
    }

    /** Снимок экрана с ожиданием. Нельзя вызывать из основного потока. */
    fun shotSync(): Bitmap? {
        val box = arrayOfNulls<Bitmap>(1)
        for (attempt in 0..1) {
            val latch = CountDownLatch(1)
            shot { b -> box[0] = b; latch.countDown() }
            latch.await(4, TimeUnit.SECONDS)
            if (box[0] != null) return box[0]
            Thread.sleep(1200)
        }
        return null
    }
}
