package com.axel.app

import java.net.HttpURLConnection
import java.net.URL

object Net {
    fun get(url: String): String? = try {
        val con = URL(url).openConnection() as HttpURLConnection
        con.connectTimeout = 8000
        con.readTimeout = 10000
        con.setRequestProperty("User-Agent", "Axel/3.0")
        if (con.responseCode in 200..299) con.inputStream.bufferedReader().readText() else null
    } catch (e: Exception) { null }
}
