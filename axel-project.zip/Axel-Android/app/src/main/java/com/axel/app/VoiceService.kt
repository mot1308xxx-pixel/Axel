package com.axel.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** Служба голосового режима «звонка»: Axel вас слушает (в том числе при открытом приложении). Пробуждение по имени «Аксель». */
class VoiceService : Service(), RecognitionListener {
    companion object {
        @Volatile var instance: VoiceService? = null
        const val ACT_MUTE = "axel.mute"
        const val ACT_OFF = "axel.off"
        fun start(c: Context) { try { ContextCompat.startForegroundService(c, Intent(c, VoiceService::class.java)) } catch (e: Exception) { } }
        fun stop(c: Context) { try { c.stopService(Intent(c, VoiceService::class.java)) } catch (e: Exception) { } }
    }

    private val h = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    @Volatile private var speaking = false
    private var awaitUntil = 0L
    private fun prefs() = getSharedPreferences("axel", 0)

    /** Пробуждение по имени: «Аксель», «Алекс», «Axel» и частые варианты распознавания. */
    private fun wakeRegex(): Regex {
        val p = (prefs().getString("phrase", "аксель") ?: "аксель").lowercase().replace('ё', 'е').replace(Regex("[^\\p{L}\\p{N} ]"), " ").trim().replace(Regex("\\s+"), " ")
        val alts = if (p == "аксель" || p.isEmpty())
            listOf("аксель", "алекс", "эксель", "оксель", "аксел", "алсель", "axel", "alexei", "aleksey")
        else listOf(p)
        val body = alts.joinToString("|") { s -> s.split(" ").joinToString("\\s+") { w -> Regex.escape(w) } }
        return Regex("(?:^|\\s)(?:(?:эй|привет|окей|ok|слушай|ну)\\s+)?(?:$body)[,.!?]?\\s*(.*)$")
    }

    override fun onBind(i: Intent?): IBinder? = null

    private fun buildNotif(): Notification {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        fun act(a: String, rc: Int) = PendingIntent.getService(this, rc, Intent(this, VoiceService::class.java).setAction(a), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val muted = Speaker.muted(this)
        return Notification.Builder(this, "axel").setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Axel вас слушает")
            .setContentText(if (muted) "Скажите: «Аксель, …». Голос выключен" else "Скажите: «Аксель, …»")
            .setContentIntent(open).setOngoing(true)
            .addAction(android.R.drawable.ic_lock_silent_mode, if (muted) "Включить голос" else "Без звука", act(ACT_MUTE, 1))
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Выключить", act(ACT_OFF, 2))
            .build()
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("axel", "Axel", NotificationManager.IMPORTANCE_LOW))
        try { ServiceCompat.startForeground(this, 1, buildNotif(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) } catch (e: Exception) { stopSelf(); return }
        Speaker.init(this)
        Speaker.onState = { sp ->
            h.post {
                speaking = sp
                if (sp) { h.removeCallbacksAndMessages(null); sr?.destroy(); sr = null } else again(600)
            }
        }
        listen()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            ACT_MUTE -> {
                Speaker.setMuted(this, !Speaker.muted(this))
                getSystemService(NotificationManager::class.java).notify(1, buildNotif())
                MainActivity.inst?.syncUi()
            }
            ACT_OFF -> {
                // Полное выключение голосового режима: и служба, и плавающий кружок.
                prefs().edit().putBoolean("enabled", false).putBoolean("callmode", false).apply()
                OverlayService.stop(this)
                MainActivity.inst?.syncUi()
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun listen() {
        h.removeCallbacksAndMessages(null)
        if (instance == null || speaking) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        sr?.destroy()
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        r.setRecognitionListener(this)
        sr = r
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, prefs().getString("lang", "ru-RU") ?: "ru-RU")
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3))
    }

    private fun again(d: Long) { h.postDelayed({ listen() }, d) }

    private fun handle(text: String) {
        val low = text.lowercase().replace('ё', 'е').trim()
        if (low.isEmpty()) return
        val m = wakeRegex().find(low)
        val now = System.currentTimeMillis()
        val cmd: String = when {
            m != null -> m.groupValues[1].trim()
            now < awaitUntil -> low
            else -> return
        }
        if (cmd.isEmpty()) { awaitUntil = now + 8000; Speaker.say(this, "Слушаю"); return }
        Thread {
            val rep = try { Brain.handle(this, cmd, null) } catch (e: Exception) { Brain.Reply("Ошибка: " + (e.message ?: ""), emptyList()) }
            h.post { deliver(cmd, rep) }
        }.start()
    }

    /** Тихий запуск: никаких Toast, только спокойный голосовой ответ. */
    private fun deliver(cmd: String, rep: Brain.Reply) {
        awaitUntil = System.currentTimeMillis() + 8000
        if (rep.say.isNotBlank()) Speaker.say(this, rep.say)
        Brain.log(this, cmd, rep)
    }

    override fun onResults(b: Bundle?) {
        val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
        handle(t)
        if (!speaking) again(200)
    }
    override fun onError(e: Int) { if (!speaking) again(if (e == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200 else 250) }
    override fun onReadyForSpeech(p: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(v: Float) {}
    override fun onBufferReceived(b: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onPartialResults(b: Bundle?) {}
    override fun onEvent(t: Int, b: Bundle?) {}

    override fun onDestroy() {
        instance = null
        Speaker.onState = null
        h.removeCallbacksAndMessages(null)
        sr?.destroy()
        super.onDestroy()
    }
}
