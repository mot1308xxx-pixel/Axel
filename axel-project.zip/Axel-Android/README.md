# Axel — голосовой ИИ-ассистент для Android

Axel (мужской род) — персональный голосовой ИИ-ассистент: чат с ИИ, живой голосовой режим «звонок» с плавающим кружком поверх всех окон, скрытое зрение экрана (Axel сам находит и нажимает кнопки в других приложениях), управление телефоном голосом, генерация картинок, мужская озвучка на нескольких языках.

## Что внутри

- `app/src/main/assets/index.html` — весь интерфейс Axel (тёмная тема, чат, настройки, шкала лимитов API).
- `app/src/main/java/com/axel/app/` — логика Android: мост WebView, фоновое распознавание «Аксель», плавающий кружок (OverlayService), AccessibilityService (нажатия, свайпы, скрытые скриншоты), Vision-поиск кнопок по скриншоту, TTS, локальный разбор команд.
- `.github/workflows/build.yml` — автосборка APK на GitHub Actions.

## Разрешения Android (все уже объявлены в манифесте)

- `INTERNET`, `ACCESS_NETWORK_STATE` — связь с ИИ-сервисом.
- `RECORD_AUDIO` + `FOREGROUND_SERVICE_MICROPHONE` — голосовое общение и фоновое распознавание «Аксель».
- `SYSTEM_ALERT_WINDOW` — плавающий кружок Axel поверх других приложений в режиме «звонка».
- `POST_NOTIFICATIONS`, `FOREGROUND_SERVICE` — уведомление «Axel вас слушает» с кнопкой «Выключить».
- AccessibilityService (специальные возможности) — реальные нажатия `dispatchGesture`, свайпы, ввод текста, скрытые скриншоты экрана (кэш 3–5 с, JPEG 80%, только в оперативной памяти, в чат не отправляются).
- `WRITE_SETTINGS` — яркость; `SET_ALARM` — таймеры и будильники; `QUERY_ALL_PACKAGES` — тихий запуск любых приложений; `REQUEST_IGNORE_BATTERY_OPTIMIZATIONS` — стабильная фоновая работа.

## Сборка APK

1. Загрузите содержимое этой папки в репозиторий GitHub (корень репозитория).
2. Вкладка **Actions** → workflow **Build Axel APK** → **Run workflow** (или просто push в `main`).
3. Готовый APK: **Artifacts → Axel-APK** или в разделе **Releases → latest-build**.

После установки: дайте Axel разрешения (микрофон, уведомления, специальные возможности, «Поверх других окон») — приложение само предложит на экране «Разрешения Android». Затем вставьте API-ключ в ⚙️ Настройки (OpenRouter — модель `google/gemma-4-26b-a4b-it:free` по умолчанию, или Google Gemini — `gemini-2.5-flash`).

Требования сборки: JDK 17, Gradle 8.9, Android Gradle Plugin 8.5.2, compileSdk 34.
