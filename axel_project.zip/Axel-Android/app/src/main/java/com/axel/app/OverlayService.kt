package com.axel.app

import android.annotation.SuppressLint
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Плавающий кружок Axel («A») поверх всех окон. Нажатие на кружок показывает РОВНО ОДНУ
 *  круглую кнопку ✕: она всегда появляется со стороны, противоположной краю экрана
 *  (кружок у левого края — ✕ справа, у правого — ✕ слева), поэтому никогда не обрезается. */
class OverlayService : Service() {
    companion object {
        @Volatile var instance: OverlayService? = null
        fun start(c: Context) { try { c.startService(Intent(c, OverlayService::class.java)) } catch (e: Exception) { } }
        fun stop(c: Context) { try { c.stopService(Intent(c, OverlayService::class.java)) } catch (e: Exception) { } }
    }

    private var wm: WindowManager? = null
    private var row: LinearLayout? = null
    private var bubble: TextView? = null
    private var closeBtn: TextView? = null
    private var expanded = false
    private var leftEdge = true
    private val params = WindowManager.LayoutParams()

    private val BG = 0xF2060607.toInt()
    private val CLOSE_BG = 0xF214161B.toInt()
    private val ACCENT = 0xFF2F6BFF.toInt()

    private fun px(d: Int) = (d * resources.displayMetrics.density).toInt()
    private fun bubbleSize() = px(60)
    private fun closeSize() = px(42)
    private fun gap() = px(6)

    @SuppressLint("ClickableViewAccessibility", "RtlHardcoded")
    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val wmP = wm!!

        fun circle(label: String, size: Int, bg: Int, onClick: () -> Unit): TextView = TextView(this).apply {
            text = label; textSize = if (size > 50) 22f else 17f
            setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
            background = GradientDrawable().apply {
                setColor(bg); cornerRadius = px(size / 2).toFloat()
                setStroke(px(2), ACCENT)
            }
            layoutParams = LinearLayout.LayoutParams(px(size), px(size))
            setOnClickListener { onClick() }
        }

        bubble = circle("A", 60, BG) { }
        closeBtn = circle("\u2715", 42, CLOSE_BG) { shutDown() }
        closeBtn?.visibility = View.GONE

        row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, 0)
        }
        row?.addView(bubble)

        params.gravity = Gravity.TOP or Gravity.START
        params.width = WindowManager.LayoutParams.WRAP_CONTENT
        params.height = WindowManager.LayoutParams.WRAP_CONTENT
        params.type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        params.flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        params.format = PixelFormat.TRANSLUCENT
        params.x = px(2)
        params.y = px(180)

        var downX = 0f; var downY = 0f
        var curX = 0; var curY = 0
        var moved = false
        val view = row!!

        bubble?.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; curX = params.x; curY = params.y; moved = false; true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - downX).toInt(); val dy = (e.rawY - downY).toInt()
                    if (Math.abs(dx) > px(6) || Math.abs(dy) > px(6)) {
                        moved = true
                        if (expanded) collapse()
                        val h = resources.displayMetrics.heightPixels
                        params.x = (curX + dx).coerceIn(0, resources.displayMetrics.widthPixels - bubbleSize())
                        params.y = (curY + dy).coerceIn(px(20), h - px(80))
                        try { wmP.updateViewLayout(view, params) } catch (ex: Exception) { }
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) { if (expanded) collapse() else expand() }
                    snap()
                    if (expanded) placeClose()
                    true
                }
                else -> false
            }
        }

        try { wmP.addView(view, params) } catch (e: Exception) { stopSelf() }
    }

    /** Прилипание к ближайшему краю: кружок у левого края — ✕ появится СПРАВА, у правого — СЛЕВА. */
    private fun snap() {
        val w = resources.displayMetrics.widthPixels
        val pad = px(2)
        leftEdge = (params.x + bubbleSize() / 2) <= w / 2
        params.x = if (leftEdge) pad else w - bubbleSize() - pad
        try { wm!!.updateViewLayout(row!!, params) } catch (e: Exception) { }
    }

    /** Показываем ОДНУ кнопку ✕ рядом с кружком, всегда внутри экрана. */
    private fun placeClose() {
        val w = resources.displayMetrics.widthPixels
        val pad = px(2)
        val extra = closeSize() + gap()
        row!!.removeAllViews()
        if (leftEdge) {
            // ✕ справа от кружка
            val lp = LinearLayout.LayoutParams(closeSize(), closeSize()).apply { marginStart = gap() }
            closeBtn?.layoutParams = lp
            row!!.addView(bubble)
            row!!.addView(closeBtn)
            params.x = minOf(params.x, w - bubbleSize() - gap() - closeSize() - pad)
        } else {
            // ✕ слева от кружка: сдвигаем окно влево, но кружок остаётся на месте
            val lp = LinearLayout.LayoutParams(closeSize(), closeSize()).apply { marginEnd = gap() }
            closeBtn?.layoutParams = lp
            row!!.addView(closeBtn)
            row!!.addView(bubble)
            params.x = (params.x - extra).coerceIn(0, w - bubbleSize() - pad)
        }
        closeBtn?.visibility = View.VISIBLE
        try { wm!!.updateViewLayout(row!!, params) } catch (e: Exception) { }
    }

    private fun expand() {
        expanded = true
        placeClose()
    }

    private fun collapse() {
        expanded = false
        closeBtn?.visibility = View.GONE
        row!!.removeAllViews()
        row!!.addView(bubble)
        try { wm!!.updateViewLayout(row!!, params) } catch (e: Exception) { }
    }

    /** ✕ — полностью отключает голосовой режим и убирает кружок. */
    private fun shutDown() {
        expanded = false
        getSharedPreferences("axel", 0).edit().putBoolean("enabled", false).putBoolean("callmode", false).apply()
        VoiceService.stop(this)
        MainActivity.inst?.syncUi()
        stopSelf()
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int = START_STICKY

    override fun onDestroy() {
        instance = null
        try { row?.let { wm?.removeView(it) } } catch (e: Exception) { }
        row = null; bubble = null; closeBtn = null
        super.onDestroy()
    }

    override fun onBind(i: Intent?): IBinder? = null
}
