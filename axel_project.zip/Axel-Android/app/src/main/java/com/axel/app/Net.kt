package com.axel.app

import java.net.URL
import org.json.JSONArray
import org.json.JSONObject

object Net {
    fun get(url: String): String? = try {
        val con = URL(url).openConnection() as java.net.HttpURLConnection
        con.connectTimeout = 8000
        con.readTimeout = 10000
        con.setRequestProperty("User-Agent", "Axel/3.0")
        if (con.responseCode in 200..299) con.inputStream.bufferedReader().readText() else null
    } catch (e: Exception) { null }

    /** JSON null в Android превращается в строку "null" — принимаем только настоящую непустую строку. */
    fun cleanText(s: String?): String? {
        val t = s?.trim() ?: return null
        if (t.isEmpty() || t.equals("null", true) || t.equals("undefined", true)) return null
        return t
    }

    /** content -> reasoning/reasoning_content, без optString("content") поверх null. */
    fun extractContent(msg: JSONObject?): String? {
        msg ?: return null
        if (!msg.isNull("content")) {
            val c = msg.opt("content")
            if (c is String) cleanText(c)?.let { return it }
            if (c is JSONArray) {
                val sb = StringBuilder()
                for (i in 0 until c.length()) {
                    val p = c.optJSONObject(i) ?: continue
                    if (!p.isNull("text")) sb.append(p.optString("text"))
                }
                cleanText(sb.toString())?.let { return it }
            }
        }
        for (k in listOf("reasoning", "reasoning_content")) {
            if (!msg.isNull(k)) cleanText(msg.optString(k))?.let { return it }
        }
        return null
    }

    /** Один текстовый запрос к ИИ (OpenRouter chat/completions или Google Gemini generateContent с ?key=). */
    fun askAI(ai: Phone.Ai, sys: String, user: String, maxTokens: Int): String? = try {
        val gemini = ai.base.contains("generativelanguage")
        val body: JSONObject
        val url: String
        if (gemini) {
            url = ai.base + "/models/gemini-2.5-flash:generateContent?key=" + ai.key
            body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", user)))))
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                .put("generationConfig", JSONObject().put("maxOutputTokens", maxTokens).put("temperature", 0.3))
        } else {
            url = ai.base + "/chat/completions"
            val model = (ai.models.firstOrNull { it.isNotBlank() } ?: "google/gemma-4-31b-it:free")
            body = JSONObject().put("model", model).put("temperature", 0.3).put("max_tokens", maxTokens)
                .put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", sys))
                    .put(JSONObject().put("role", "user").put("content", user)))
        }
        val con = URL(url).openConnection() as java.net.HttpURLConnection
        con.requestMethod = "POST"
        con.connectTimeout = 8000
        con.readTimeout = 30000
        con.doOutput = true
        con.setRequestProperty("Content-Type", "application/json")
        if (!gemini) con.setRequestProperty("Authorization", "Bearer " + ai.key)
        con.outputStream.use { it.write(body.toString().toByteArray()) }
        if (con.responseCode !in 200..299) return null
        val j = JSONObject(con.inputStream.bufferedReader().readText())
        if (gemini) {
            val cand = j.optJSONArray("candidates")?.optJSONObject(0) ?: return null
            val parts = cand.optJSONObject("content")?.optJSONArray("parts") ?: return null
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val p = parts.optJSONObject(i) ?: continue
                if (!p.isNull("text")) sb.append(p.optString("text"))
            }
            cleanText(sb.toString())?.take(400)
        } else {
            extractContent(j.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message"))?.take(400)
        }
    } catch (e: Exception) { null }
}
